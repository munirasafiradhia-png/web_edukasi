<?php

namespace App\Http\Controllers;

use App\Models\Nilai;
use App\Models\User;
use Illuminate\Support\Facades\Gate;

class NilaiController extends Controller
{
    public function __construct()
    {
        $this->authorizeResource(Nilai::class, 'nilai');
    }

    public function siswaIndex()
    {
        $nilai = Nilai::where('user_id', auth()->id())
            ->with('kuis')
            ->latest()
            ->paginate(10);

        $rataRata = Nilai::where('user_id', auth()->id())->avg('skor') ?? 0;

        return view('siswa.nilai.index', compact('nilai', 'rataRata'));
    }

    public function guruIndex()
    {
        $nilai = Nilai::with('user', 'kuis')->latest()->paginate(10);

        return view('guru.nilai.index', compact('nilai'));
    }

    public function laporan()
    {
        Gate::authorize('viewAny', Nilai::class);

        $nilai = Nilai::with('user', 'kuis')->latest()->get();

        $rataRata = Nilai::avg('skor') ?? 0;

        return view('guru.nilai.laporan', compact('nilai', 'rataRata'));
    }
}
