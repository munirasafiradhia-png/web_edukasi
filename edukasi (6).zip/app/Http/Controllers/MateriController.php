<?php

namespace App\Http\Controllers;

use App\Models\Materi;
use App\Http\Requests\MateriRequest;
use Illuminate\Support\Facades\Storage;

class MateriController extends Controller
{
    public function __construct()
    {
        $this->authorizeResource(Materi::class, 'materi');
    }

    public function siswaIndex()
    {
        $materi = Materi::latest()->get();

        return view('siswa.materi.index', compact('materi'));
    }

    public function siswaShow(Materi $materi)
    {
        $this->authorize('view', $materi);

        return view('siswa.materi.show', compact('materi'));
    }

    public function index()
    {
        $materi = Materi::with('user')->latest()->paginate(10);

        return view('guru.materi.index', compact('materi'));
    }

    public function create()
    {
        return view('guru.materi.create');
    }

    public function store(MateriRequest $request)
    {
        $data = $request->validated();

        if ($request->hasFile('file')) {
            $data['file'] = $request->file('file')->store('materi', 'public');
        }

        $data['user_id'] = auth()->id();

        Materi::create($data);

        return redirect()->route('guru.materi.index')->with('success', 'Materi berhasil ditambahkan.');
    }

    public function edit(Materi $materi)
    {
        $this->authorize('update', $materi);

        return view('guru.materi.edit', compact('materi'));
    }

    public function update(MateriRequest $request, Materi $materi)
    {
        $this->authorize('update', $materi);

        $data = $request->validated();

        if ($request->hasFile('file')) {
            if ($materi->file) {
                Storage::disk('public')->delete($materi->file);
            }
            $data['file'] = $request->file('file')->store('materi', 'public');
        }

        $materi->update($data);

        return redirect()->route('guru.materi.index')->with('success', 'Materi berhasil diperbarui.');
    }

    public function destroy(Materi $materi)
    {
        $this->authorize('delete', $materi);

        if ($materi->file) {
            Storage::disk('public')->delete($materi->file);
        }

        $materi->delete();

        return redirect()->route('guru.materi.index')->with('success', 'Materi berhasil dihapus.');
    }
}
