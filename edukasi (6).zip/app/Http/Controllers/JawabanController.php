<?php

namespace App\Http\Controllers;

use App\Models\Kuis;
use App\Models\Soal;
use App\Models\Jawaban;
use App\Models\Nilai;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;

class JawabanController extends Controller
{
    public function create(Kuis $kuis)
    {
        Gate::authorize('create', Jawaban::class);

        $soal = $kuis->soal()->latest()->get();

        if ($soal->isEmpty()) {
            return back()->with('error', 'Kuis ini belum memiliki soal.');
        }

        $existing = Nilai::where('user_id', auth()->id())
            ->where('kuis_id', $kuis->id)
            ->first();

        if ($existing) {
            return redirect()->route('siswa.kuis.hasil', $kuis)->with('info', 'Anda sudah mengerjakan kuis ini.');
        }

        return view('siswa.kuis.mengerjakan', compact('kuis', 'soal'));
    }

    public function store(Request $request, Kuis $kuis)
    {
        Gate::authorize('create', Jawaban::class);

        $soalIds = $kuis->soal()->pluck('id');

        $validated = $request->validate(array_fill_keys(
            $soalIds->map(fn ($id) => "soal_{$id}")->toArray(),
            'required|in:A,B,C,D'
        ));

        foreach ($validated as $key => $jawaban) {
            $soalId = (int) str_replace('soal_', '', $key);

            Jawaban::updateOrCreate(
                ['user_id' => auth()->id(), 'soal_id' => $soalId],
                ['jawaban' => $jawaban]
            );
        }

        return back()->with('success', 'Jawaban disimpan. Silakan kumpulkan untuk melihat nilai.');
    }

    public function kumpulkan(Request $request, Kuis $kuis)
    {
        Gate::authorize('create', Jawaban::class);

        $existingNilai = Nilai::where('user_id', auth()->id())
            ->where('kuis_id', $kuis->id)
            ->first();

        if ($existingNilai) {
            return redirect()->route('siswa.kuis.hasil', $kuis)->with('info', 'Anda sudah mengumpulkan kuis ini.');
        }

        $soal = $kuis->soal()->get();

        if ($soal->isEmpty()) {
            return back()->with('error', 'Kuis ini belum memiliki soal.');
        }

        $jawabanUser = Jawaban::where('user_id', auth()->id())
            ->whereIn('soal_id', $soal->pluck('id'))
            ->get()
            ->keyBy('soal_id');

        $benar = 0;
        $total = $soal->count();

        foreach ($soal as $s) {
            $j = $jawabanUser->get($s->id);
            if ($j && $j->jawaban === $s->kunci_jawaban) {
                $benar++;
            }
        }

        $skor = $total > 0 ? (int) round(($benar / $total) * 100) : 0;

        DB::transaction(function () use ($kuis, $skor) {
            Nilai::create([
                'user_id' => auth()->id(),
                'kuis_id' => $kuis->id,
                'skor' => $skor,
            ]);
        });

        return redirect()->route('siswa.kuis.hasil', $kuis)
            ->with('benar', $benar)
            ->with('total', $total)
            ->with('skor', $skor);
    }

    public function hasil(Kuis $kuis)
    {
        Gate::authorize('view', Jawaban::class);

        $nilai = Nilai::where('user_id', auth()->id())
            ->where('kuis_id', $kuis->id)
            ->first();

        if (!$nilai) {
            return back()->with('error', 'Belum ada nilai untuk kuis ini.');
        }

        $soal = $kuis->soal()->get();
        $jawaban = Jawaban::where('user_id', auth()->id())
            ->whereIn('soal_id', $soal->pluck('id'))
            ->get()
            ->keyBy('soal_id');

        $benar = 0;
        $total = $soal->count();

        foreach ($soal as $s) {
            $j = $jawaban->get($s->id);
            if ($j && $j->jawaban === $s->kunci_jawaban) {
                $benar++;
            }
        }

        return view('siswa.kuis.hasil', compact('kuis', 'nilai', 'benar', 'total'));
    }
}
