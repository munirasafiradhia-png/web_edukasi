<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Http\Requests\ProfilRequest;
use App\Http\Requests\PasswordRequest;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Gate;

class ProfilController extends Controller
{
    public function edit()
    {
        $user = auth()->user();

        Gate::authorize('view', $user);

        return view('profil.edit', compact('user'));
    }

    public function update(ProfilRequest $request)
    {
        $user = auth()->user();

        Gate::authorize('update', $user);

        $data = $request->validated();

        // Role tidak boleh diubah melalui form profil
        unset($data['role']);

        $user->update($data);

        return back()->with('success', 'Profil berhasil diperbarui.');
    }

    public function updatePassword(PasswordRequest $request)
    {
        $user = auth()->user();

        Gate::authorize('update', $user);

        if (!Hash::check($request->password_lama, $user->password)) {
            return back()->withErrors(['password_lama' => 'Password lama salah.']);
        }

        $user->update([
            'password' => Hash::make($request->password_baru),
        ]);

        return back()->with('success', 'Password berhasil diubah.');
    }
}
