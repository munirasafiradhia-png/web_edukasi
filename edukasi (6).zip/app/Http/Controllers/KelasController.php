<?php

namespace App\Http\Controllers;

use App\Models\Kelas;
use App\Http\Requests\KelasRequest;

class KelasController extends Controller
{
    public function __construct()
    {
        $this->authorizeResource(Kelas::class, 'kelas');
    }

    public function index()
    {
        $kelas = Kelas::latest()->paginate(10);

        return view('admin.kelas.index', compact('kelas'));
    }

    public function create()
    {
        return view('admin.kelas.create');
    }

    public function store(KelasRequest $request)
    {
        Kelas::create($request->validated());

        return redirect()->route('admin.kelas.index')->with('success', 'Kelas berhasil ditambahkan.');
    }

    public function edit(Kelas $kelas)
    {
        return view('admin.kelas.edit', compact('kelas'));
    }

    public function update(KelasRequest $request, Kelas $kelas)
    {
        $kelas->update($request->validated());

        return redirect()->route('admin.kelas.index')->with('success', 'Kelas berhasil diperbarui.');
    }

    public function destroy(Kelas $kelas)
    {
        $kelas->delete();

        return redirect()->route('admin.kelas.index')->with('success', 'Kelas berhasil dihapus.');
    }
}
