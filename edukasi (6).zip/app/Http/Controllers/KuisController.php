<?php

namespace App\Http\Controllers;

use App\Models\Kuis;
use App\Http\Requests\KuisRequest;
use Illuminate\Support\Facades\Gate;

class KuisController extends Controller
{
    public function __construct()
    {
        $this->authorizeResource(Kuis::class, 'kuis');
    }

    public function siswaIndex()
    {
        $kuis = Kuis::with('user')->latest()->get();

        return view('siswa.kuis.index', compact('kuis'));
    }

    public function index()
    {
        $kuis = Kuis::with('user')->latest()->paginate(10);

        return view('guru.kuis.index', compact('kuis'));
    }

    public function create()
    {
        return view('guru.kuis.create');
    }

    public function store(KuisRequest $request)
    {
        $data = $request->validated();
        $data['user_id'] = auth()->id();

        Kuis::create($data);

        return redirect()->route('guru.kuis.index')->with('success', 'Kuis berhasil dibuat.');
    }

    public function edit(Kuis $kuis)
    {
        $this->authorize('update', $kuis);

        return view('guru.kuis.edit', compact('kuis'));
    }

    public function update(KuisRequest $request, Kuis $kuis)
    {
        $this->authorize('update', $kuis);

        $kuis->update($request->validated());

        return redirect()->route('guru.kuis.index')->with('success', 'Kuis berhasil diperbarui.');
    }

    public function destroy(Kuis $kuis)
    {
        $this->authorize('delete', $kuis);

        $kuis->delete();

        return redirect()->route('guru.kuis.index')->with('success', 'Kuis berhasil dihapus.');
    }
}
