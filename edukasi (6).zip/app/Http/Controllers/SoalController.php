<?php

namespace App\Http\Controllers;

use App\Models\Kuis;
use App\Models\Soal;
use App\Http\Requests\SoalRequest;
use Illuminate\Support\Facades\Gate;

class SoalController extends Controller
{
    public function index(Kuis $kuis)
    {
        Gate::authorize('viewAny', Soal::class);

        $soal = $kuis->soal()->latest()->get();

        return view('guru.soal.index', compact('kuis', 'soal'));
    }

    public function create(Kuis $kuis)
    {
        Gate::authorize('create', Soal::class);

        return view('guru.soal.create', compact('kuis'));
    }

    public function store(SoalRequest $request, Kuis $kuis)
    {
        Gate::authorize('create', Soal::class);

        $data = $request->validated();
        $data['kuis_id'] = $kuis->id;

        Soal::create($data);

        $kuis->increment('jumlah_soal');

        return redirect()->route('guru.kuis.soal.index', $kuis)->with('success', 'Soal berhasil ditambahkan.');
    }

    public function edit(Kuis $kuis, Soal $soal)
    {
        Gate::authorize('update', $soal);

        return view('guru.soal.edit', compact('kuis', 'soal'));
    }

    public function update(SoalRequest $request, Kuis $kuis, Soal $soal)
    {
        Gate::authorize('update', $soal);

        $soal->update($request->validated());

        return redirect()->route('guru.kuis.soal.index', $kuis)->with('success', 'Soal berhasil diperbarui.');
    }

    public function destroy(Kuis $kuis, Soal $soal)
    {
        Gate::authorize('delete', $soal);

        $soal->delete();

        $kuis->decrement('jumlah_soal');

        return redirect()->route('guru.kuis.soal.index', $kuis)->with('success', 'Soal berhasil dihapus.');
    }
}
