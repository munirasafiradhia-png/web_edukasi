<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Materi;
use App\Models\Kuis;
use App\Models\Nilai;
use App\Models\Soal;
use App\Models\Jawaban;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function show()
    {
        $user = auth()->user();

        return match ($user->role) {
            'admin' => $this->admin(),
            'guru' => $this->guru(),
            default => $this->siswa(),
        };
    }

    public function siswa()
    {
        $user = auth()->user();

        $data = [
            'jumlah_materi' => Materi::count(),
            'jumlah_kuis' => Kuis::count(),
            'rata_rata_nilai' => Nilai::where('user_id', $user->id)->avg('skor') ?? 0,
            'materi_terbaru' => Materi::latest()->take(5)->get(),
            'nilai_terbaru' => Nilai::where('user_id', $user->id)->with('kuis')->latest()->take(5)->get(),
        ];

        return view('siswa.dashboard', $data);
    }

    public function guru()
    {
        $user = auth()->user();

        $data = [
            'jumlah_materi' => Materi::where('user_id', $user->id)->count(),
            'jumlah_kuis' => Kuis::where('user_id', $user->id)->count(),
            'jumlah_siswa' => User::where('role', 'siswa')->count(),
            'nilai_terbaru' => Nilai::with('user', 'kuis')->latest()->take(10)->get(),
        ];

        return view('guru.dashboard', $data);
    }

    public function admin()
    {
        $data = [
            'jumlah_pengguna' => User::count(),
            'jumlah_siswa' => User::where('role', 'siswa')->count(),
            'jumlah_guru' => User::where('role', 'guru')->count(),
            'jumlah_admin' => User::where('role', 'admin')->count(),
            'jumlah_materi' => Materi::count(),
            'jumlah_kuis' => Kuis::count(),
            'aktivitas_terbaru' => User::latest()->take(10)->get(),
        ];

        return view('admin.dashboard', $data);
    }
}
