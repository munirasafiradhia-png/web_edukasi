<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class KuisRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'judul' => 'required|string|max:255',
            'jumlah_soal' => 'required|integer|min:1',
            'tanggal' => 'required|date',
            'kelas_id' => 'nullable|exists:kelas,id',
        ];
    }

    public function messages(): array
    {
        return [
            'judul.required' => 'Judul kuis wajib diisi.',
            'jumlah_soal.required' => 'Jumlah soal wajib diisi.',
            'tanggal.required' => 'Tanggal kuis wajib diisi.',
        ];
    }
}
