<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MateriRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'file' => 'nullable|file|max:10240|mimes:pdf,doc,docx,ppt,pptx,txt,zip',
        ];
    }

    public function messages(): array
    {
        return [
            'judul.required' => 'Judul materi wajib diisi.',
            'deskripsi.required' => 'Deskripsi materi wajib diisi.',
            'file.max' => 'Ukuran file maksimal 10 MB.',
            'file.mimes' => 'Tipe file tidak diizinkan.',
        ];
    }
}
