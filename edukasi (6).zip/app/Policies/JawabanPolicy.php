<?php

namespace App\Policies;

use App\Models\Jawaban;
use App\Models\User;

class JawabanPolicy
{
    public function viewAny(User $user): bool
    {
        return in_array($user->role, ['admin', 'guru'], true);
    }

    public function view(User $user, Jawaban $jawaban): bool
    {
        if ($user->isAdmin() || $user->isGuru()) {
            return true;
        }

        return $jawaban->user_id === $user->id;
    }

    public function create(User $user): bool
    {
        return $user->isSiswa();
    }
}
