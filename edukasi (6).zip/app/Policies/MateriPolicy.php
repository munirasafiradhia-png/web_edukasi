<?php

namespace App\Policies;

use App\Models\Materi;
use App\Models\User;

class MateriPolicy
{
    public function viewAny(User $user): bool
    {
        return in_array($user->role, ['admin', 'guru', 'siswa'], true);
    }

    public function view(User $user, Materi $materi): bool
    {
        return in_array($user->role, ['admin', 'guru', 'siswa'], true);
    }

    public function create(User $user): bool
    {
        return $user->isGuru() || $user->isAdmin();
    }

    public function update(User $user, Materi $materi): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        return $user->isGuru() && $materi->user_id === $user->id;
    }

    public function delete(User $user, Materi $materi): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        return $user->isGuru() && $materi->user_id === $user->id;
    }
}
