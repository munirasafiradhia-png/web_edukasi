<?php

namespace App\Policies;

use App\Models\Kuis;
use App\Models\User;

class KuisPolicy
{
    public function viewAny(User $user): bool
    {
        return in_array($user->role, ['admin', 'guru', 'siswa'], true);
    }

    public function view(User $user, Kuis $kuis): bool
    {
        return in_array($user->role, ['admin', 'guru', 'siswa'], true);
    }

    public function create(User $user): bool
    {
        return $user->isGuru() || $user->isAdmin();
    }

    public function update(User $user, Kuis $kuis): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        return $user->isGuru() && $kuis->user_id === $user->id;
    }

    public function delete(User $user, Kuis $kuis): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        return $user->isGuru() && $kuis->user_id === $user->id;
    }
}
