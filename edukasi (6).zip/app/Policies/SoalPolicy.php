<?php

namespace App\Policies;

use App\Models\Soal;
use App\Models\User;

class SoalPolicy
{
    public function viewAny(User $user): bool
    {
        return in_array($user->role, ['admin', 'guru', 'siswa'], true);
    }

    public function view(User $user, Soal $soal): bool
    {
        return in_array($user->role, ['admin', 'guru', 'siswa'], true);
    }

    public function create(User $user): bool
    {
        return $user->isGuru() || $user->isAdmin();
    }

    public function update(User $user, Soal $soal): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        return $user->isGuru() && $soal->kuis->user_id === $user->id;
    }

    public function delete(User $user, Soal $soal): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        return $user->isGuru() && $soal->kuis->user_id === $user->id;
    }
}
