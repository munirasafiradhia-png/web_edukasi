<?php

namespace App\Policies;

use App\Models\Nilai;
use App\Models\User;

class NilaiPolicy
{
    public function viewAny(User $user): bool
    {
        return in_array($user->role, ['admin', 'guru', 'siswa'], true);
    }

    public function view(User $user, Nilai $nilai): bool
    {
        if ($user->isAdmin() || $user->isGuru()) {
            return true;
        }

        return $nilai->user_id === $user->id;
    }
}
