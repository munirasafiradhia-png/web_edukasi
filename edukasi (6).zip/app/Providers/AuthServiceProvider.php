<?php

namespace App\Providers;

use App\Models\User;
use App\Models\Materi;
use App\Models\Kuis;
use App\Models\Soal;
use App\Models\Jawaban;
use App\Models\Nilai;
use App\Models\Kelas;
use App\Policies\MateriPolicy;
use App\Policies\KuisPolicy;
use App\Policies\SoalPolicy;
use App\Policies\JawabanPolicy;
use App\Policies\NilaiPolicy;
use App\Policies\KelasPolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    protected $policies = [
        User::class => \App\Policies\UserPolicy::class,
        Materi::class => MateriPolicy::class,
        Kuis::class => KuisPolicy::class,
        Soal::class => SoalPolicy::class,
        Jawaban::class => JawabanPolicy::class,
        Nilai::class => NilaiPolicy::class,
        Kelas::class => KelasPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        //
    }
}
