<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kelas extends Model
{
    use HasFactory;

    protected $table = 'kelas';

    protected $fillable = [
        'nama',
        'deskripsi',
    ];

    public function kuis()
    {
        return $this->hasMany(Kuis::class, 'kelas_id');
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'kelas_siswa', 'kelas_id', 'user_id');
    }
}
