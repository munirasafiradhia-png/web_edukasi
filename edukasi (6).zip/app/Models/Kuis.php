<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kuis extends Model
{
    use HasFactory;

    protected $table = 'kuis';

    protected $fillable = [
        'judul',
        'jumlah_soal',
        'tanggal',
        'user_id',
        'kelas_id',
    ];

    protected $casts = [
        'tanggal' => 'date',
        'jumlah_soal' => 'integer',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function kelas()
    {
        return $this->belongsTo(Kelas::class, 'kelas_id');
    }

    public function soal()
    {
        return $this->hasMany(Soal::class, 'kuis_id');
    }

    public function nilai()
    {
        return $this->hasMany(Nilai::class, 'kuis_id');
    }
}
