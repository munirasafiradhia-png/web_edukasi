<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('nilai', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('kuis_id')->constrained('kuis')->onDelete('cascade');
            $table->integer('skor'); // 0-100
            $table->timestamp('tanggal')->useCurrent();
            $table->timestamps();

            $table->unique(['user_id', 'kuis_id']); // cegah duplikasi nilai per kuis per siswa
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('nilai');
    }
};
