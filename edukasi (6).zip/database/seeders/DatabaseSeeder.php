<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Kelas;
use App\Models\Materi;
use App\Models\Kuis;
use App\Models\Soal;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Akun demo pengembangan
        $admin = User::create([
            'name' => 'Admin Sistem',
            'email' => 'admin@portal.edu',
            'password' => Hash::make('admin123'),
            'role' => 'admin',
        ]);

        $guru = User::create([
            'name' => 'Guru Demo',
            'email' => 'guru@portal.edu',
            'password' => Hash::make('guru123'),
            'role' => 'guru',
        ]);

        $siswa1 = User::create([
            'name' => 'Siswa Satu',
            'email' => 'siswa@portal.edu',
            'password' => Hash::make('siswa123'),
            'role' => 'siswa',
        ]);

        $siswa2 = User::create([
            'name' => 'Siswa Dua',
            'email' => 'siswa2@portal.edu',
            'password' => Hash::make('siswa123'),
            'role' => 'siswa',
        ]);

        // Kelas pendukung (tabel non-ERD, dokumentasi di README)
        $kelasXipa = Kelas::create([
            'nama' => 'X IPA 1',
            'deskripsi' => 'Kelas X IPA 1',
        ]);

        $kelasXips = Kelas::create([
            'nama' => 'X IPS 1',
            'deskripsi' => 'Kelas X IPS 1',
        ]);

        // Materi contoh sesuai wireframe/dokumen
        $materiEkosistem = Materi::create([
            'judul' => 'Pengertian Ekosistem',
            'deskripsi' => 'Materi tentang pengertian ekosistem, komponen ekosistem, dan interaksi antara makhluk hidup dengan lingkungannya.',
            'file' => null,
            'user_id' => $guru->id,
        ]);

        $materiSiklusAir = Materi::create([
            'judul' => 'Siklus Air',
            'deskripsi' => 'Materi tentang siklus air di dalam lingkungan, termasuk evaporasi, kondensasi, dan presipitasi.',
            'file' => null,
            'user_id' => $guru->id,
        ]);

        $materiEnergi = Materi::create([
            'judul' => 'Energi dan Perubahannya',
            'deskripsi' => 'Materi tentang bentuk-bentuk energi dan proses transformasi energi dari satu bentuk ke bentuk lain.',
            'file' => null,
            'user_id' => $guru->id,
        ]);

        // Kuis 1: Ekosistem
        $kuisEkosistem = Kuis::create([
            'judul' => 'Kuis Pengertian Ekosistem',
            'jumlah_soal' => 0,
            'tanggal' => now(),
            'user_id' => $guru->id,
            'kelas_id' => $kelasXipa->id,
        ]);

        $soalEkosistem1 = Soal::create([
            'kuis_id' => $kuisEkosistem->id,
            'pertanyaan' => 'Apa yang dimaksud dengan ekosistem?',
            'opsi_a' => 'Kumpulan makhluk hidup saja',
            'opsi_b' => 'Komunitas makhluk hidup dan lingkungannya yang saling berinteraksi',
            'opsi_c' => 'Lingkungan non-organik saja',
            'opsi_d' => 'Suatu jenis hewan',
            'kunci_jawaban' => 'B',
        ]);

        $soalEkosistem2 = Soal::create([
            'kuis_id' => $kuisEkosistem->id,
            'pertanyaan' => 'Manakah contoh komponen biotik dalam ekosistem?',
            'opsi_a' => 'Air',
            'opsi_b' => 'Sinar matahari',
            'opsi_c' => 'Pohon',
            'opsi_d' => 'Batuan',
            'kunci_jawaban' => 'C',
        ]);

        $soalEkosistem3 = Soal::create([
            'kuis_id' => $kuisEkosistem->id,
            'pertanyaan' => 'Apa fungsi decomposer dalam ekosistem?',
            'opsi_a' => 'Memproduksi makanan',
            'opsi_b' => 'Mengurai organisme mati',
            'opsi_c' => 'Menyerap sinar matahari',
            'opsi_d' => 'Menghasilkan oksigen',
            'kunci_jawaban' => 'B',
        ]);

        $kuisEkosistem->update(['jumlah_soal' => $kuisEkosistem->soal()->count()]);

        // Kuis 2: Siklus Air
        $kuisSiklusAir = Kuis::create([
            'judul' => 'Kuis Siklus Air',
            'jumlah_soal' => 0,
            'tanggal' => now()->addDays(1),
            'user_id' => $guru->id,
            'kelas_id' => $kelasXips->id,
        ]);

        $soalSiklus1 = Soal::create([
            'kuis_id' => $kuisSiklusAir->id,
            'pertanyaan' => 'Proses air berubah dari cair menjadi uap disebut?',
            'opsi_a' => 'Kondensasi',
            'opsi_b' => 'Presipitasi',
            'opsi_c' => 'Evaporasi',
            'opsi_d' => 'Infilterasi',
            'kunci_jawaban' => 'C',
        ]);

        $soalSiklus2 = Soal::create([
            'kuis_id' => $kuisSiklusAir->id,
            'pertanyaan' => 'Hujan adalah bagian dari proses?',
            'opsi_a' => 'Evaporasi',
            'opsi_b' => 'Presipitasi',
            'opsi_c' => 'Kondensasi',
            'opsi_d' => 'Transpirasi',
            'kunci_jawaban' => 'B',
        ]);

        $kuisSiklusAir->update(['jumlah_soal' => $kuisSiklusAir->soal()->count()]);

        // Kuis 3: Energi
        $kuisEnergi = Kuis::create([
            'judul' => 'Kuis Energi dan Perubahannya',
            'jumlah_soal' => 0,
            'tanggal' => now()->addDays(2),
            'user_id' => $guru->id,
        ]);

        $soalEnergi1 = Soal::create([
            'kuis_id' => $kuisEnergi->id,
            'pertanyaan' => 'Manakah contoh energi kinetik?',
            'opsi_a' => 'Benda di atas meja',
            'opsi_b' => 'Bola yang bergerak',
            'opsi_c' => 'Baterai',
            'opsi_d' => 'Makanan',
            'kunci_jawaban' => 'B',
        ]);

        $soalEnergi2 = Soal::create([
            'kuis_id' => $kuisEnergi->id,
            'pertanyaan' => 'Energi listrik diubah menjadi energi cahaya pada?',
            'opsi_a' => 'Kipas angin',
            'opsi_b' => 'Lampu',
            'opsi_c' => 'Kompor listrik',
            'opsi_d' => 'Radio',
            'kunci_jawaban' => 'B',
        ]);

        $kuisEnergi->update(['jumlah_soal' => $kuisEnergi->soal()->count()]);
    }
}
