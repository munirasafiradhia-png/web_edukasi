<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login Laravel</title>
  <style>
    body { font-family: sans-serif; background: #f0f4f8; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
    .box { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); width: 300px; }
    h2 { text-align: center; }
    input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 5px; box-sizing: border-box; }
    button { width: 100%; padding: 10px; background: #3b82f6; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; }
    .error { color: red; font-size: 14px; text-align: center; }
  </style>
</head>
<body>
  <div class="box">
    <h2>Masuk Laravel</h2>
    @if(session('error'))
      <p class="error">{{ session('error') }}</p>
    @endif
    <form action="/proses-login" method="POST">
      @csrf
      <input type="email" name="email" placeholder="Email (admin@gmail.com)" required>
      <input type="password" name="password" placeholder="Password (123)" required>
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>