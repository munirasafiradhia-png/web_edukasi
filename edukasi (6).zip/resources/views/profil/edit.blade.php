<x-layout title="Profil">
    <div class="max-w-xl mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h1 class="text-lg font-bold text-gray-900">Pengaturan Profil</h1>
            </div>

            <div class="p-6 space-y-8">
                <!-- Form nama & email -->
                <div>
                    <h2 class="text-sm font-semibold text-gray-700 uppercase mb-4">Informasi Akun</h2>

                    <form action="{{ route('profil.update') }}" method="POST" class="space-y-4">
                        @csrf
                        @method('PUT')

                        <x-input name="name" label="Nama Lengkap" value="{{ old('name', $user->name) }}" required />
                        <x-input name="email" label="Email" value="{{ old('email', $user->email) }}" required />

                        <div class="flex gap-3">
                            <x-button type="submit" label="Simpan Perubahan" />
                            @if (session('success'))
                                <span class="text-sm text-green-600 mt-[34px] block">{{ session('success') }}</span>
                            @endif
                        </div>
                    </form>
                </div>

                <!-- Form password -->
                <div>
                    <h2 class="text-sm font-semibold text-gray-700 uppercase mb-4">Ubah Password</h2>

                    <form action="{{ route('profil.password') }}" method="POST" class="space-y-4">
                        @csrf

                        <x-input name="password_lama" label="Password Lama" type="password" required />
                        <x-input name="password_baru" label="Password Baru" type="password" required />
                        <x-input name="password_baru_confirmation" label="Konfirmasi Password Baru" type="password" required />

                        <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2.5 rounded-lg font-medium transition shadow-md">
                            Ubah Password
                        </button>
                    </form>
                </div>

                <div class="pt-4 border-t border-gray-200">
                    <p class="text-xs text-gray-400 uppercase font-semibold">Role: <span class="text-gray-600 capitalize">{{ $user->role }}</span></p>
                    <p class="text-xs text-gray-500 mt-1">Role tidak dapat diubah melalui halaman ini.</p>
                </div>
            </div>
        </div>
    </div>
</x-layout>
