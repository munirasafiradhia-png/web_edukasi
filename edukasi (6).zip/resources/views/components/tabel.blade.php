@props(['items' => [], 'columns' => []])

<div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
    <table class="w-full text-left border-collapse">
        <thead class="bg-gray-50 border-b border-gray-200">
            <tr>
                @foreach ($columns as $col)
                    <th class="px-6 py-3 text-xs font-semibold text-gray-500 uppercase">{{ $col }}</th>
                @endforeach
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            @foreach ($items as $item)
                <tr class="hover:bg-gray-50 transition">
                    @php $__loopIdx = $loop->index + 1; @endphp
                    <td class="px-6 py-4 text-sm text-gray-900">{{ $__loopIdx }}</td>
                    @foreach ($columns as $index => $col)
                        @if ($index === 0)
                            @continue
                        @endif
                        @php
                            $prop = strtolower(str_replace(' ', '', $col));
                        @endphp
                        <td class="px-6 py-4 text-sm text-gray-600">{{ $item->$prop ?? $item[$prop] ?? '-' }}</td>
                    @endforeach
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
