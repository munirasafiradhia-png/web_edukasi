@php
    $isActive = request()->routeIs($route);
@endphp

<a href="{{ route($route) }}" onclick="document.getElementById('mobileSidebar').classList.add('-translate-x-full')" class="block flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition {{ $isActive ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-100' }}">
    <i class="fas {{ $icon }}"></i>
    <span>{{ $label }}</span>
</a>
