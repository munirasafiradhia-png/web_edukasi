@props(['type' => 'submit', 'label' => 'Simpan', 'color' => 'blue', 'class' => ''])

<button
    type="{{ $type }}"
    class="w-full px-4 py-2.5 rounded-lg font-medium text-white transition
    {{ $color === 'blue' ? 'bg-blue-600 hover:bg-blue-700' : ($color === 'green' ? 'bg-green-600 hover:bg-green-700' : ($color === 'red' ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-600 hover:bg-gray-700')) }}
    {{ $class }}"
>{{ $label }}</button>
