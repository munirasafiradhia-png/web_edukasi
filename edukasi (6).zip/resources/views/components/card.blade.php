@props(['color' => 'blue', 'label' => '', 'value' => '', 'icon' => 'fa-info-circle'])

<div class="bg-white rounded-xl shadow border border-gray-200 p-6">
    <div class="flex items-center gap-4">
        <div class="p-3 rounded-lg {{ $color === 'blue' ? 'bg-blue-100 text-blue-600' : ($color === 'green' ? 'bg-green-100 text-green-600' : ($color === 'purple' ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-600')) }}">
            <i class="fas {{ $icon }}"></i>
        </div>
        <div>
            <p class="text-sm text-gray-500 font-medium">{{ $label }}</p>
            <p class="text-2xl font-bold text-gray-900">{{ $value }}</p>
        </div>
    </div>
</div>
