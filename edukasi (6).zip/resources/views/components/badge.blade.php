@props(['label' => '', 'value' => '', 'color' => 'blue'])

<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
    {{ $color === 'blue' ? 'bg-blue-100 text-blue-700' : ($color === 'green' ? 'bg-green-100 text-green-700' : ($color === 'red' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700')) }}">
    {{ $value }}
</span>
