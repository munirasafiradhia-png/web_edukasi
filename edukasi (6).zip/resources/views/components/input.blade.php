@props(['type' => 'text', 'name' => '', 'label' => '', 'value' => old($name), 'placeholder' => '', 'required' => true, 'error' => $errors->first($name)])

<div class="mb-4">
    @if ($label)
        <label for="{{ $name }}" class="block text-sm font-medium text-gray-700 mb-1">{{ $label }}</label>
    @endif

    <input
        id="{{ $name }}"
        name="{{ $name }}"
        type="{{ $type }}"
        value="{{ old($name) ?? $value ?? '' }}"
        placeholder="{{ $placeholder }}"
        {{ $required ? 'required' : '' }}
        class="w-full px-4 py-2.5 border rounded-lg text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition {{ $error ? 'border-red-500' : 'border-gray-300' }} @error($name) border-red-500 @enderror"
    >

    @if ($error)
        <p class="mt-1 text-sm text-red-600">{{ $error }}</p>
    @endif
</div>
