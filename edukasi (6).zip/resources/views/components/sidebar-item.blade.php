@php
    $isActive = request()->routeIs($route);
@endphp

<a href="{{ route($route) }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition {{ $isActive ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-100' }}">
    <i class="fas {{ $icon }}"></i>
    <span>{{ $label }}</span>
</a>
