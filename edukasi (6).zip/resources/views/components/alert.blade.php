@props(['message' => '', 'type' => 'success'])

@if ($message)
    <div class="mb-6 p-4 rounded-lg border {{ $type === 'success' ? 'bg-green-50 border-green-200 text-green-800' : ($type === 'error' ? 'bg-red-50 border-red-200 text-red-800' : 'bg-blue-50 border-blue-200 text-blue-800') }}">
        {{ $message }}
    </div>
@endif
