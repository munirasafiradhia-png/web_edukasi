<header class="bg-white shadow border-b border-gray-200 sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <div class="flex items-center gap-3">
                <div class="bg-blue-600 rounded-lg p-2">
                    <i class="fas fa-graduation-cap text-white text-xl"></i>
                </div>
                <div>
                    <h1 class="font-bold text-xl text-gray-900 leading-tight">Portal Edukasi</h1>
                    <p class="text-xs text-gray-500">Media Pembelajaran Interaktif</p>
                </div>
            </div>

            <div class="flex items-center gap-4">
                <span class="hidden sm:inline-block text-sm text-gray-600">
                    Hallo, {{ auth()->user()->name }}
                </span>
                <div class="flex items-center gap-2 pl-4 border-l border-gray-200">
                    <a href="{{ route('profil.edit') }}" class="text-sm text-gray-600 hover:text-blue-600 transition">
                        Profil
                    </a>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-sm text-gray-600 hover:text-red-600 transition">
                            Keluar
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>
