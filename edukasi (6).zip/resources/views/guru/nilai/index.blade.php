<x-layout title="Nilai Siswa">
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Nilai Siswa</h1>
                <p class="text-gray-600">Lihat semua nilai pengerjaan kuis siswa.</p>
            </div>
        </div>
    </div>

    <x-alert :message="session('success')" type="success" />

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        @if ($nilai->isEmpty())
            <div class="p-12 text-center">
                <div class="text-gray-400 mb-4"><i class="fas fa-star text-4xl"></i></div>
                <p class="text-gray-500">Belum ada nilai siswa.</p>
            </div>
        @else
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">No</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Siswa</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Kuis</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Skor</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Tanggal</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @php $no = 1; @endphp
                        @foreach ($nilai as $n)
                            <tr>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $no++ }}</td>
                                <td class="px-6 py-4 text-sm text-gray-700">{{ optional($n->user)->name ?? '-' }}</td>
                                <td class="px-6 py-4 text-sm text-gray-700">{{ optional($n->kuis)->judul ?? '-' }}</td>
                                <td class="px-6 py-4 text-sm font-medium {{ $n->skor >= 80 ? 'text-green-600' : 'text-gray-900' }}">{{ $n->skor }}</td>
                                <td class="px-6 py-4 text-sm text-gray-500">{{ $n->tanggal?->format('d M Y H:i') ?? '-' }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{ $nilai->links() }}
        @endif
    </div>
</x-layout>
