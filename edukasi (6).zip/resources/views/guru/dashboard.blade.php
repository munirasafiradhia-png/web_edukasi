<x-layout title="Dashboard Guru">
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-900">Dashboard Guru</h1>
        <p class="text-gray-600">Kelola materi dan kuis pembelajaran Anda.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <x-card :color="'blue'" :label="'Materi yang Dikelola'" :value="$jumlah_materi" :icon="'fa-book'" />
        <x-card :color="'green'" :label="'Kuis yang Dibuat'" :value="$jumlah_kuis" :icon="'fa-clipboard-list'" />
        <x-card :color="'purple'" :label="'Total Siswa'" :value="$jumlah_siswa" :icon="'fa-users'" />
        <x-card :color="'indigo'" :label="'Nilai Terbaru'" :value=" $nilai_terbaru->count() " :icon="'fa-star'" />
    </div>

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Nilai Terbaru</h2>
        </div>
        <div class="p-6">
            @if ($nilai_terbaru->isEmpty())
                <p class="text-gray-500 text-center py-8">Belum ada nilai.</p>
            @else
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Siswa</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Kuis</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Skor</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            @foreach ($nilai_terbaru as $n)
                                <tr>
                                    <td class="px-6 py-4 text-sm text-gray-700">{{ optional($n->user)->name ?? '-' }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-700">{{ optional($n->kuis)->judul ?? '-' }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-900 font-semibold">{{ $n->skor }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-500">{{ $n->tanggal?->format('d M Y') ?? '-' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
</x-layout>
