<x-layout title="Edit Soal">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 p-8">
            <h1 class="text-2xl font-bold text-gray-900 mb-6">Edit Soal</h1>
            <p class="text-sm text-gray-500 mb-6">Kuis: <span class="font-semibold text-gray-900">{{ $kuis->judul }}</span></p>

            <form action="{{ route('guru.kuis.soal.update', [$kuis, $soal]) }}" method="POST" class="space-y-6">
                @csrf
                @method('PUT')

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Pertanyaan</label>
                    <textarea name="pertanyaan" rows="4" required
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">{{ old('pertanyaan', $soal->pertanyaan) }}</textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Opsi A</label>
                        <input type="text" name="opsi_a" required
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition" value="{{ old('opsi_a', $soal->opsi_a) }}">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Opsi B</label>
                        <input type="text" name="opsi_b" required
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition" value="{{ old('opsi_b', $soal->opsi_b) }}">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Opsi C</label>
                        <input type="text" name="opsi_c" required
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition" value="{{ old('opsi_c', $soal->opsi_c) }}">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Opsi D</label>
                        <input type="text" name="opsi_d" required
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition" value="{{ old('opsi_d', $soal->opsi_d) }}">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Kunci Jawaban</label>
                    <select name="kunci_jawaban" required
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                        <option value="A" {{ old('kunci_jawaban', $soal->kunci_jawaban) === 'A' ? 'selected' : '' }}>A</option>
                        <option value="B" {{ old('kunci_jawaban', $soal->kunci_jawaban) === 'B' ? 'selected' : '' }}>B</option>
                        <option value="C" {{ old('kunci_jawaban', $soal->kunci_jawaban) === 'C' ? 'selected' : '' }}>C</option>
                        <option value="D" {{ old('kunci_jawaban', $soal->kunci_jawaban) === 'D' ? 'selected' : '' }}>D</option>
                    </select>
                </div>

                <div class="flex gap-3 pt-4">
                    <x-button type="submit" label="Perbarui Soal" />
                    <a href="{{ route('guru.kuis.soal.index', $kuis) }}" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</x-layout>
