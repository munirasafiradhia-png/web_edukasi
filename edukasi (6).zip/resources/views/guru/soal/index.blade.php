<x-layout title="Kelola Soal - {{ $kuis->judul }}">
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Kelola Soal</h1>
                <p class="text-gray-600">Kuis: <span class="font-semibold">{{ $kuis->judul }}</span></p>
            </div>
            <a href="{{ route('guru.kuis.soal.create', $kuis) }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg font-medium transition shadow-md">
                <i class="fas fa-plus mr-2"></i> Tambah Soal
            </a>
        </div>
    </div>

    <x-alert :message="session('success')" type="success" />

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        @if ($soal->isEmpty())
            <div class="p-12 text-center">
                <div class="text-gray-400 mb-4"><i class="fas fa-question-circle text-4xl"></i></div>
                <p class="text-gray-500">Belum ada soal untuk kuis ini.</p>
                <a href="{{ route('guru.kuis.soal.create', $kuis) }}" class="mt-4 inline-block text-blue-600 font-medium hover:underline">Tambah Soal Pertama</a>
            </div>
        @else
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">No</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Pertanyaan</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Kunci Jawaban</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @php $no = 1; @endphp
                        @foreach ($soal as $s)
                            <tr>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $no++ }}</td>
                                <td class="px-6 py-4 text-sm text-gray-700">{{ $s->pertanyaan }}</td>
                                <td class="px-6 py-4 text-sm font-medium">
                                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-bold">{{ $s->kunci_jawaban }}</span>
                                </td>
                                <td class="px-6 py-4 text-sm text-right">
                                    <a href="{{ route('guru.kuis.soal.edit', [$kuis, $s]) }}" class="text-blue-600 hover:underline mr-3">Edit</a>
                                    <form action="{{ route('guru.kuis.soal.destroy', [$kuis, $s]) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:underline" onclick="return confirm('Yakin ingin menghapus soal ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>
</x-layout>
