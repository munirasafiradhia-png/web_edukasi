<x-layout title="Kelola Materi">
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Kelola Materi</h1>
                <p class="text-gray-600">Kelola materi pembelajaran yang Anda buat.</p>
            </div>
            <a href="{{ route('guru.materi.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg font-medium transition shadow-md">
                <i class="fas fa-plus mr-2"></i> Tambah Materi
            </a>
        </div>
    </div>

    <x-alert :message="session('success')" type="success" />
    @if (session('error'))
        <x-alert :message="session('error')" type="error" />
    @endif

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        @if ($materi->isEmpty())
            <div class="p-12 text-center">
                <div class="text-gray-400 mb-4"><i class="fas fa-book-open text-4xl"></i></div>
                <p class="text-gray-500">Belum ada materi. Mulai menambahkan materi pertama.</p>
                <a href="{{ route('guru.materi.create') }}" class="mt-4 inline-block text-blue-600 font-medium hover:underline">Tambah Materi</a>
            </div>
        @else
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">No</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Judul</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Deskripsi</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">File</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Tanggal</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @php $no = 1; @endphp
                        @foreach ($materi as $m)
                            <tr>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $no++ }}</td>
                                <td class="px-6 py-4 text-sm font-medium text-gray-900">{{ $m->judul }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ Str::limit($m->deskripsi, 60) }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $m->file ? basename($m->file) : '-' }}</td>
                                <td class="px-6 py-4 text-sm text-gray-500">{{ $m->created_at?->format('d M Y') ?? '-' }}</td>
                                <td class="px-6 py-4 text-sm text-right">
                                    <a href="{{ route('guru.materi.edit', $m) }}" class="text-blue-600 hover:underline mr-3">Edit</a>
                                    <form action="{{ route('guru.materi.destroy', $m) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:underline" onclick="return confirm('Yakin ingin menghapus materi ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{ $materi->links() }}
        @endif
    </div>
</x-layout>
