<x-layout title="Tambah Materi">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 p-8">
            <h1 class="text-2xl font-bold text-gray-900 mb-6">Tambah Materi</h1>

            <form action="{{ route('guru.materi.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                @csrf

                <x-input name="judul" label="Judul Materi" placeholder="Contoh: Pengertian Ekosistem" required />

                <x-input name="deskripsi" label="Deskripsi" type="textarea" placeholder="Ceritakan singkat tentang materi ini" required />

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">File Materi</label>
                    <input type="file" name="file"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    <p class="mt-1 text-xs text-gray-500">Tipe: pdf, doc, docx, ppt, pptx, txt, zip. Maksimal 10 MB.</p>
                </div>

                <div class="flex gap-3 pt-4">
                    <x-button type="submit" label="Simpan Materi" />
                    <a href="{{ route('guru.materi.index') }}" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</x-layout>
