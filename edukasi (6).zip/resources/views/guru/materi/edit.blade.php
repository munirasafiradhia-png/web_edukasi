<x-layout title="Edit Materi">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 p-8">
            <h1 class="text-2xl font-bold text-gray-900 mb-6">Edit Materi</h1>

            <form action="{{ route('guru.materi.update', $materi) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                @csrf
                @method('PUT')

                <x-input name="judul" label="Judul Materi" value="{{ old('judul', $materi->judul) }}" required />

                <x-input name="deskripsi" label="Deskripsi" value="{{ old('deskripsi', $materi->deskripsi) }}" required />

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">File Materi (kosongkan jika tidak diubah)</label>
                    <input type="file" name="file"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    @if ($materi->file)
                        <p class="mt-1 text-xs text-gray-500">File saat ini: {{ basename($materi->file) }}</p>
                    @endif
                    <p class="mt-1 text-xs text-gray-500">Tipe: pdf, doc, docx, ppt, pptx, txt, zip. Maksimal 10 MB.</p>
                </div>

                <div class="flex gap-3 pt-4">
                    <x-button type="submit" label="Perbarui Materi" />
                    <a href="{{ route('guru.materi.index') }}" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</x-layout>
