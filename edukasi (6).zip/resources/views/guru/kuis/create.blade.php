<x-layout title="Buat Kuis">
    <div class="max-w-lg mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 p-8">
            <h1 class="text-2xl font-bold text-gray-900 mb-6">Buat Kuis Baru</h1>

            <form action="{{ route('guru.kuis.store') }}" method="POST" class="space-y-6">
                @csrf

                <x-input name="judul" label="Judul Kuis" placeholder="Contoh: Kuis Ekosistem Kelas X" required />

                <x-input name="jumlah_soal" label="Jumlah Soal" type="number" min="1" value="5" required />

                <x-input name="tanggal" label="Tanggal Kuis" type="date" required />

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Kelas</label>
                    <select name="kelas_id" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                        <option value="">Pilih kelas (opsional)</option>
                        @php $kelas = \App\Models\Kelas::all(); @endphp
                        @foreach ($kelas as $kls)
                            <option value="{{ $kls->id }}">{{ $kls->nama }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="flex gap-3 pt-4">
                    <x-button type="submit" label="Buat Kuis" />
                    <a href="{{ route('guru.kuis.index') }}" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</x-layout>
