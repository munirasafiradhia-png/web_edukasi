<x-layout title="Edit Kuis">
    <div class="max-w-lg mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 p-8">
            <h1 class="text-2xl font-bold text-gray-900 mb-6">Edit Kuis</h1>

            <form action="{{ route('guru.kuis.update', $kuis) }}" method="POST" class="space-y-6">
                @csrf
                @method('PUT')

                <x-input name="judul" label="Judul Kuis" value="{{ old('judul', $kuis->judul) }}" required />

                <x-input name="jumlah_soal" label="Jumlah Soal" type="number" min="1" value="{{ old('jumlah_soal', $kuis->jumlah_soal) }}" required />

                <x-input name="tanggal" label="Tanggal Kuis" type="date" value="{{ old('tanggal', $kuis->tanggal?->format('Y-m-d')) }}" required />

                <div class="flex gap-3 pt-4">
                    <x-button type="submit" label="Perbarui Kuis" />
                    <a href="{{ route('guru.kuis.index') }}" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</x-layout>
