<x-layout title="Kelola Kuis">
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Kelola Kuis</h1>
                <p class="text-gray-600">Buat dan kelola kuis untuk siswa.</p>
            </div>
            <a href="{{ route('guru.kuis.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg font-medium transition shadow-md">
                <i class="fas fa-plus mr-2"></i> Buat Kuis
            </a>
        </div>
    </div>

    <x-alert :message="session('success')" type="success" />

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        @if ($kuis->isEmpty())
            <div class="p-12 text-center">
                <div class="text-gray-400 mb-4"><i class="fas fa-clipboard-list text-4xl"></i></div>
                <p class="text-gray-500">Belum ada kuis. Buat kuis pertama Anda.</p>
                <a href="{{ route('guru.kuis.create') }}" class="mt-4 inline-block text-blue-600 font-medium hover:underline">Buat Kuis</a>
            </div>
        @else
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">No</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Judul</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Jumlah Soal</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Tanggal</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @php $no = 1; @endphp
                        @foreach ($kuis as $k)
                            <tr>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $no++ }}</td>
                                <td class="px-6 py-4 text-sm font-medium text-gray-900">{{ $k->judul }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $k->jumlah_soal }} soal</td>
                                <td class="px-6 py-4 text-sm text-gray-500">{{ $k->tanggal?->format('d M Y') ?? '-' }}</td>
                                <td class="px-6 py-4 text-sm text-right">
                                    <a href="{{ route('guru.kuis.soal.index', $k) }}" class="text-blue-600 hover:underline mr-3">Kelola Soal</a>
                                    <a href="{{ route('guru.kuis.edit', $k) }}" class="text-blue-600 hover:underline mr-3">Edit</a>
                                    <form action="{{ route('guru.kuis.destroy', $k) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:underline" onclick="return confirm('Yakin ingin menghapus kuis ini? Semua soal dan nilai terkait akan ikut terhapus.')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{ $kuis->links() }}
        @endif
    </div>
</x-layout>
