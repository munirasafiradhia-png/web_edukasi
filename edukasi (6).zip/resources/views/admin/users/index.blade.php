<x-layout title="Kelola Pengguna">
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Kelola Pengguna</h1>
                <p class="text-gray-600">Kelola akun siswa, guru, dan admin.</p>
            </div>
            <a href="{{ route('admin.users.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg font-medium transition shadow-md">
                <i class="fas fa-plus mr-2"></i> Tambah Pengguna
            </a>
        </div>
    </div>

    <x-alert :message="session('success')" type="success" />
    @if (session('error'))
        <x-alert :message="session('error')" type="error" />
    @endif

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        @if ($users->isEmpty())
            <div class="p-12 text-center">
                <div class="text-gray-400 mb-4"><i class="fas fa-users text-4xl"></i></div>
                <p class="text-gray-500">Belum ada pengguna.</p>
            </div>
        @else
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">No</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Nama</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Email</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Role</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @php $no = 1; @endphp
                        @foreach ($users as $u)
                            <tr>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $no++ }}</td>
                                <td class="px-6 py-4 text-sm font-medium text-gray-900">{{ $u->name }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $u->email }}</td>
                                <td class="px-6 py-4 text-sm">
                                    <x-badge :value="strtoupper($u->role)" :color="$u->role === 'admin' ? 'red' : ($u->role === 'guru' ? 'blue' : 'green')" />
                                </td>
                                <td class="px-6 py-4 text-sm text-right">
                                    @if ($u->id !== auth()->id())
                                        <a href="{{ route('admin.users.edit', $u) }}" class="text-blue-600 hover:underline mr-3">Edit</a>
                                        <form action="{{ route('admin.users.destroy', $u) }}" method="POST" class="inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:underline" onclick="return confirm('Yakin ingin menghapus pengguna ini?')">Hapus</button>
                                        </form>
                                    @else
                                        <span class="text-gray-400 text-xs">Anda</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{ $users->links() }}
        @endif
    </div>
</x-layout>
