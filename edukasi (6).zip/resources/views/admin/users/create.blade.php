<x-layout title="Tambah Pengguna">
    <div class="max-w-lg mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 p-8">
            <h1 class="text-2xl font-bold text-gray-900 mb-6">Tambah Pengguna</h1>

            <form action="{{ route('admin.users.store') }}" method="POST" class="space-y-6">
                @csrf

                <x-input name="name" label="Nama Lengkap" placeholder="Contoh: Budi Santoso" required />
                <x-input name="email" label="Email" placeholder="nama@email.com" required />
                <x-input name="password" label="Password" type="password" required />

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Role</label>
                    <select name="role" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                        <option value="siswa">Siswa</option>
                        <option value="guru">Guru</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>

                <div class="flex gap-3 pt-4">
                    <x-button type="submit" label="Simpan Pengguna" />
                    <a href="{{ route('admin.users.index') }}" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</x-layout>
