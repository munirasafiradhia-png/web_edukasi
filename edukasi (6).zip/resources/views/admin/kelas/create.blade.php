<x-layout title="Tambah Kelas">
    <div class="max-w-lg mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 p-8">
            <h1 class="text-2xl font-bold text-gray-900 mb-6">Tambah Kelas</h1>

            <form action="{{ route('admin.kelas.store') }}" method="POST" class="space-y-6">
                @csrf

                <x-input name="nama" label="Nama Kelas" placeholder="Contoh: X IPA 1" required />
                <x-input name="deskripsi" label="Deskripsi" placeholder="Deskripsi singkat tentang kelas" />

                <div class="flex gap-3 pt-4">
                    <x-button type="submit" label="Simpan Kelas" />
                    <a href="{{ route('admin.kelas.index') }}" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</x-layout>
