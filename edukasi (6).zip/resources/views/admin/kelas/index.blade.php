<x-layout title="Kelola Kelas">
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Kelola Kelas</h1>
                <p class="text-gray-600">Kelola kelas yang tersedia di sistem.</p>
            </div>
            <a href="{{ route('admin.kelas.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg font-medium transition shadow-md">
                <i class="fas fa-plus mr-2"></i> Tambah Kelas
            </a>
        </div>
    </div>

    <x-alert :message="session('success')" type="success" />

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        @if ($kelas->isEmpty())
            <div class="p-12 text-center">
                <div class="text-gray-400 mb-4"><i class="fas fa-school text-4xl"></i></div>
                <p class="text-gray-500">Belum ada kelas.</p>
                <a href="{{ route('admin.kelas.create') }}" class="mt-4 inline-block text-blue-600 font-medium hover:underline">Tambah Kelas</a>
            </div>
        @else
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">No</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Nama Kelas</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Deskripsi</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @php $no = 1; @endphp
                        @foreach ($kelas as $k)
                            <tr>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $no++ }}</td>
                                <td class="px-6 py-4 text-sm font-medium text-gray-900">{{ $k->nama }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $k->deskripsi ?? '-' }}</td>
                                <td class="px-6 py-4 text-sm text-right">
                                    <a href="{{ route('admin.kelas.edit', $k) }}" class="text-blue-600 hover:underline mr-3">Edit</a>
                                    <form action="{{ route('admin.kelas.destroy', $k) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:underline" onclick="return confirm('Yakin ingin menghapus kelas ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{ $kelas->links() }}
        @endif
    </div>
</x-layout>
