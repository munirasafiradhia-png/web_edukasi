<x-layout title="Laporan Sistem">
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-900">Laporan Aktivitas Pengguna</h1>
        <p class="text-gray-600">Lihat ringkasan pengguna dan nilai yang telah dicapai.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <x-card :color="'blue'" :label="'Total Pengguna'" :value=" $users->total() " :icon="'fa-users'" />
        <x-card :color="'green'" :label="'Siswa Aktif'" :value=" $users->where('role', 'siswa')->count() " :icon="'fa-user-graduate'" />
        <x-card :color="'purple'" :label="'Guru'" :value=" $users->where('role', 'guru')->count() " :icon="'fa-chalkboard-teacher'" />
    </div>

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Daftar Pengguna dan Nilai</h2>
        </div>
        <div class="p-6">
            @if ($users->isEmpty())
                <p class="text-gray-500 text-center py-8">Belum ada data pengguna.</p>
            @else
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">No</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Nama</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Email</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Role</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Jumlah Nilai</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500 text-right">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            @php $no = 1; @endphp
                            @foreach ($users as $u)
                                <tr>
                                    <td class="px-6 py-4 text-sm text-gray-600">{{ $no++ }}</td>
                                    <td class="px-6 py-4 text-sm font-medium text-gray-900">{{ $u->name }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-600">{{ $u->email }}</td>
                                    <td class="px-6 py-4 text-sm">
                                        <x-badge :value="strtoupper($u->role)" :color="$u->role === 'admin' ? 'red' : ($u->role === 'guru' ? 'blue' : 'green')" />
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-600">{{ $u->nilai_count }}</td>
                                    <td class="px-6 py-4 text-sm text-right">
                                        <a href="{{ route('admin.users.edit', $u) }}" class="text-blue-600 hover:underline mr-3">Edit</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="mt-4 flex justify-end">
                    {{ $users->links() }}
                </div>
            @endif
        </div>
    </div>
</x-layout>
