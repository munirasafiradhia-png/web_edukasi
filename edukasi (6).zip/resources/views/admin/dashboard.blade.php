<x-layout title="Dashboard Admin">
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-900">Dashboard Admin</h1>
        <p class="text-gray-600">Kelola pengguna, kelas, dan laporan sistem.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <x-card :color="'blue'" :label="'Total Pengguna'" :value="$jumlah_pengguna" :icon="'fa-users'" />
        <x-card :color="'green'" :label="'Siswa'" :value="$jumlah_siswa" :icon="'fa-user-graduate'" />
        <x-card :color="'purple'" :label="'Guru'" :value="$jumlah_guru" :icon="'fa-chalkboard-teacher'" />
        <x-card :color="'indigo'" :label="'Admin'" :value="$jumlah_admin" :icon="'fa-shield-halved'" />
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-900">Materi &amp; Kuis</h2>
            </div>
            <div class="p-6 space-y-4">
                <div class="flex justify-between items-center">
                    <span class="text-gray-700">Total Materi</span>
                    <span class="text-xl font-bold text-gray-900">{{ $jumlah_materi }}</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-700">Total Kuis</span>
                    <span class="text-xl font-bold text-gray-900">{{ $jumlah_kuis }}</span>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-900">Pengguna Terbaru</h2>
            </div>
            <div class="p-6">
                @if ($aktivitas_terbaru->isEmpty())
                    <p class="text-gray-500 text-center py-8">Belum ada pengguna.</p>
                @else
                    <ul class="divide-y divide-gray-200">
                        @foreach ($aktivitas_terbaru as $u)
                            <li class="py-3 flex items-center justify-between">
                                <div>
                                    <p class="text-sm font-medium text-gray-900">{{ $u->name }}</p>
                                    <p class="text-xs text-gray-500">{{ $u->email }} <span class="bg-gray-100 px-2 py-0.5 rounded text-[10px] uppercase font-semibold">{{ $u->role }}</span></p>
                                </div>
                                <a href="{{ route('admin.users.edit', $u) }}" class="text-sm text-blue-600 hover:underline">Edit</a>
                            </li>
                        @endforeach
                    </ul>
                @endif
            </div>
        </div>
    </div>
</x-layout>
