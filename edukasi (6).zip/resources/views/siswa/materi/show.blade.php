<x-layout title="Detail Materi">
    <div class="max-w-3xl">
        <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
            <div class="p-6">
                <div class="flex justify-between items-start mb-6">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900 mb-2">{{ $materi->judul }}</h1>
                        <p class="text-gray-600">{{ $materi->deskripsi }}</p>
                    </div>
                    <span class="text-xs font-semibold text-blue-600 bg-blue-50 px-3 py-1 rounded-full uppercase">
                        Diupload {{ $materi->created_at?->format('d M Y') ?? '-' }}
                    </span>
                </div>

                @if ($materi->file)
                    <div class="mb-6">
                        <a href="{{ Storage::url($materi->file) }}" target="_blank" class="flex items-center gap-3 px-4 py-3 bg-blue-50 border border-blue-200 rounded-lg text-blue-700 font-medium hover:bg-blue-100 transition">
                            <i class="fas fa-download text-xl"></i>
                            <span>Unduh File Materi</span>
                        </a>
                    </div>
                @else
                    <div class="mb-6 p-4 rounded-lg bg-gray-50 text-gray-500 text-sm text-center">
                        Tidak ada file lampiran untuk materi ini.
                    </div>
                @endif

                <div class="flex gap-3">
                    <a href="{{ route('siswa.materi') }}" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                        Kembali ke Daftar Materi
                    </a>
                </div>
            </div>
        </div>
    </div>
</x-layout>
