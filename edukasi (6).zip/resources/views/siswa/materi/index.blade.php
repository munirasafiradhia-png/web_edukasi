<x-layout title="Materi Pembelajaran">
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-900">Materi Pembelajaran</h1>
        <p class="text-gray-600">Akses materi pembelajaran yang tersedia.</p>
    </div>

    @if ($materi->isEmpty())
        <div class="bg-white rounded-xl shadow border border-gray-200 p-12 text-center">
            <div class="text-gray-400 mb-4"><i class="fas fa-book-open text-4xl"></i></div>
            <h3 class="text-lg font-semibold text-gray-900 mb-2">Belum ada materi</h3>
            <p class="text-gray-500">Materi pembelajaran akan segera tersedia.</p>
        </div>
    @else
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach ($materi as $m)
                <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden hover:shadow-lg transition group">
                    <div class="p-6">
                        <div class="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-600 group-hover:text-white transition">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <h3 class="text-lg font-bold text-gray-900 mb-2">{{ $m->judul }}</h3>
                        <p class="text-gray-600 text-sm mb-4 line-clamp-2">{{ $m->deskripsi }}</p>
                        <div class="flex items-center justify-between pt-4 border-t border-gray-100">
                            <span class="text-xs text-gray-500 uppercase font-semibold">{{ optional($m->user)->name ?? '-' }}</span>
                            <a href="{{ route('siswa.materi.show', $m) }}" class="text-sm text-blue-600 font-medium hover:underline flex items-center gap-1">
                                Baca <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @endif
</x-layout>
