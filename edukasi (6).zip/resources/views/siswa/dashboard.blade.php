<x-layout title="Dashboard">
    <!-- Header judul halaman -->
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p class="text-gray-600">Selamat datang kembali, <span class="font-semibold">{{ auth()->user()->name }}</span>.</p>
    </div>

    <!-- Ringkasan card -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <x-card :color="'blue'" :label="'Materi Tersedia'" :value="$jumlah_materi" :icon="'fa-book'" />
        <x-card :color="'green'" :label="'Kuis Tersedia'" :value="$jumlah_kuis" :icon="'fa-clipboard-list'" />
        <x-card :color="'purple'" :label="'Nilai Rata-Rata'" :value="$rata_rata_nilai" :icon="'fa-star'" />
    </div>

    <!-- Materi terbaru -->
    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Materi Terbaru</h2>
        </div>
        <div class="p-6">
            @if ($materi_terbaru->isEmpty())
                <p class="text-gray-500 text-center py-8">Belum ada materi tersedia.</p>
            @else
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    @foreach ($materi_terbaru as $m)
                        <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                            <h3 class="font-semibold text-gray-900">{{ $m->judul }}</h3>
                            <p class="text-sm text-gray-500 mt-1">{{ Str::limit($m->deskripsi, 80) }}</p>
                            <a href="{{ route('siswa.materi.show', $m) }}" class="mt-3 inline-block text-sm text-blue-600 font-medium hover:underline">
                                Baca Materi <i class="fas fa-arrow-right ml-1"></i>
                            </a>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>
    </div>

    <!-- Nilai terbaru -->
    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden mt-6">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Nilai Terbaru</h2>
        </div>
        <div class="p-6">
            @if ($nilai_terbaru->isEmpty())
                <p class="text-gray-500 text-center py-8">Belum ada nilai.</p>
            @else
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Kuis</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Skor</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            @foreach ($nilai_terbaru as $n)
                                <tr>
                                    <td class="px-6 py-4 text-sm text-gray-700">{{ optional($n->kuis)->judul ?? '-' }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-900 font-semibold">{{ $n->skor }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-500">{{ $n->tanggal?->format('d M Y') ?? '-' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
</x-layout>
