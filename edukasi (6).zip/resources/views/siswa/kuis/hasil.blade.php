<x-layout title="Hasil Kuis">
    <div class="max-w-lg mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h1 class="text-lg font-bold text-gray-900">Hasil Kuis</h1>
            </div>

            <div class="p-8 text-center">
                @if ($nilai)
                    <div class="mb-6">
                        <p class="text-sm text-gray-500 uppercase font-semibold">Kuis</p>
                        <h2 class="text-xl font-bold text-gray-900">{{ $kuis->judul }}</h2>
                    </div>

                    <div class="inline-block p-6 rounded-full bg-blue-50 text-blue-600 mb-6">
                        <span class="text-4xl font-bold">{{ $nilai->skor }}</span>
                        <span class="text-sm">/ 100</span>
                    </div>

                    <p class="text-gray-600 mb-6">
                        Anda menjawab <span class="font-semibold">{{ $benar }}</span> dari <span class="font-semibold">{{ $total }}</span> soal dengan benar.
                    </p>

                    @if ($nilai->skor >= 80)
                        <div class="bg-green-100 text-green-700 px-4 py-2 rounded-lg inline-block">Lulus</div>
                    @else
                        <div class="bg-red-100 text-red-700 px-4 py-2 rounded-lg inline-block">Perlu Perbaikan</div>
                    @endif

                    <p class="mt-4 text-sm text-gray-500">Tanggal: {{ $nilai->tanggal?->format('d M Y H:i') ?? '-' }}</p>
                @else
                    <p class="text-gray-500">Belum ada nilai untuk kuis ini.</p>
                @endif
            </div>

            <div class="px-6 py-4 border-t border-gray-200">
                <a href="{{ route('siswa.kuis') }}" class="block w-full text-center px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                    Kembali ke Daftar Kuis
                </a>
            </div>
        </div>
    </div>
</x-layout>
