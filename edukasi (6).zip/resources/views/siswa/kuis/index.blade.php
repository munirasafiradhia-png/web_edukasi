<x-layout title="Kuis">
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-900">Kuis</h1>
        <p class="text-gray-600">Akses kuis yang tersedia untuk Anda.</p>
    </div>

    @if ($kuis->isEmpty())
        <div class="bg-white rounded-xl shadow border border-gray-200 p-12 text-center">
            <div class="text-gray-400 mb-4"><i class="fas fa-clipboard-list text-4xl"></i></div>
            <h3 class="text-lg font-semibold text-gray-900 mb-2">Belum ada kuis</h3>
            <p class="text-gray-500">Kuis akan segera tersedia dari guru.</p>
        </div>
    @else
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach ($kuis as $k)
                <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden hover:shadow-lg transition group">
                    <div class="p-6">
                        <div class="w-12 h-12 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-600 group-hover:text-white transition">
                            <i class="fas fa-question-circle"></i>
                        </div>
                        <h3 class="text-lg font-bold text-gray-900 mb-2">{{ $k->judul }}</h3>
                        <p class="text-gray-600 text-sm mb-4">{{ $k->jumlah_soal }} soal · {{ $k->tanggal?->format('d M Y') ?? '-' }}</p>
                        <div class="flex items-center justify-between pt-4 border-t border-gray-100">
                            <span class="text-xs text-gray-500 uppercase font-semibold">{{ optional($k->user)->name ?? '-' }}</span>
                            <a href="{{ route('siswa.kuis.mengerjakan', $k) }}" class="text-sm text-purple-600 font-medium hover:underline flex items-center gap-1">
                                Mengerjakan <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @endif
</x-layout>
