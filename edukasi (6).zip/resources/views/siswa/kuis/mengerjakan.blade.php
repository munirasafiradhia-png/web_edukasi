<x-layout title="Mengerjakan Kuis">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <div>
                    <h1 class="text-lg font-bold text-gray-900">{{ $kuis->judul }}</h1>
                    <p class="text-sm text-gray-500">{{ $soal->count() }} soal · Pilihan ganda</p>
                </div>
                <div class="text-right">
                    <p class="text-sm font-medium text-gray-900">Soal <span id="counter">{{ $soal->count() }}</span></p>
                </div>
            </div>

            @if (session('error'))
                <div class="p-4 bg-red-50 border border-red-200 text-red-800 text-sm">
                    {{ session('error') }}
                </div>
            @endif

            <form action="{{ route('siswa.kuis.jawaban', $kuis) }}" method="POST" id="kuisForm" class="p-6 space-y-8">
                @csrf

                @foreach ($soal as $index => $s)
                    <div id="soal-{{ $s->id }}" class="border border-gray-200 rounded-xl p-6 mb-4 {{ $index > 0 ? 'hidden' : '' }}" data-soal="{{ $s->id }}">
                        <p class="text-lg font-semibold text-gray-900 mb-4">{{ $loop->index }}. {{ $s->pertanyaan }}</p>

                        <div class="space-y-3">
                            @foreach (['A', 'B', 'C', 'D'] as $o)
                                <label class="flex items-center gap-3 p-3 border border-gray-200 rounded-lg hover:bg-blue-50 cursor-pointer transition group">
                                    <input type="radio" name="soal_{{ $s->id }}" value="{{ $o }}"
                                        class="radio-input text-blue-600 focus:ring-blue-500"
                                        {{ old("soal_{$s->id}") === $o ? 'checked' : '' }}
                                        data-jawaban="{{ old("soal_{$s->id}") ?? '' }}">
                                    <span class="text-gray-700 font-medium">{{ $o }}. {{ $s->{'opsi_' . strtolower($o)}} }}</span>
                                </label>
                            @endforeach
                        </div>

                        <div class="mt-4 flex justify-between">
                            @if ($loop->first)
                                <button type="button" onclick="nextSoal({{ $s->id }})" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                                    Selanjutnya <i class="fas fa-arrow-right ml-1"></i>
                                </button>
                            @elseif ($loop->last)
                                <button type="button" onclick="prevSoal({{ $s->id }})" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-300 transition mr-2">
                                    <i class="fas fa-arrow-left mr-1"></i> Sebelumnya
                                </button>
                                <button type="button" onclick="kumpulkanKuis()" class="px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition">
                                    Kumpulkan Jawaban
                                </button>
                            @else
                                <button type="button" onclick="prevSoal({{ $s->id }})" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-300 transition mr-2">
                                    <i class="fas fa-arrow-left mr-1"></i> Sebelumnya
                                </button>
                                <button type="button" onclick="nextSoal({{ $s->id }})" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                                    Selanjutnya <i class="fas fa-arrow-right ml-1"></i>
                                </button>
                            @endif
                        </div>
                    </div>
                @endforeach
            </form>
        </div>
    </div>

    <script>
        function nextSoal(currentId) {
            document.getElementById('soal-' + currentId).classList.add('hidden');
            // cari soal berikutnya
            @foreach ($soal as $index => $s)
                if (currentId === {{ $s->id }} && {{ $loop->index < $soal->count() - 1 }}) {
                    document.getElementById('soal-{{ $soal[$loop->index + 1]->id }}').classList.remove('hidden');
                }
            @endforeach
        }

        function prevSoal(currentId) {
            document.getElementById('soal-' + currentId).classList.add('hidden');
            @foreach ($soal as $index => $s)
                if (currentId === {{ $s->id }} && {{ $loop->index > 0 }}) {
                    document.getElementById('soal-{{ $soal[$loop->index - 1]->id }}').classList.remove('hidden');
                }
            @endforeach
        }

        function kumpulkanKuis() {
            if (!confirm('Yakin ingin mengumpulkan jawaban? Nilai akan dihitung secara otomatis.')) {
                return;
            }
            document.getElementById('kuisForm').action = "{{ route('siswa.kuis.kumpulkan', $kuis) }}";
            document.getElementById('kuisForm').submit();
        }
    </script>
</x-layout>
