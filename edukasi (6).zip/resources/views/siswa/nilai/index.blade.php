<x-layout title="Nilai Saya">
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-900">Nilai Saya</h1>
        <p class="text-gray-600">Lihat riwayat nilai kuis yang telah Anda kerjakan.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <x-card :color="'blue'" :label="'Total Kuis Dikerjakan'" :value=" $nilai->total() " :icon="'fa-clipboard-list'" />
        <x-card :color="'green'" :label="'Nilai Tertinggi'" :value=" $nilai->max('skor') ?? 0 " :icon="'fa-trophy'" />
        <x-card :color="'purple'" :label="'Nilai Rata-Rata'" :value=" number_format($rataRata, 2) " :icon="'fa-star'" />
    </div>

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Riwayat Nilai</h2>
        </div>
        <div class="p-6">
            @if ($nilai->isEmpty())
                <div class="text-center py-12">
                    <div class="text-gray-400 mb-4"><i class="fas fa-star text-4xl"></i></div>
                    <p class="text-gray-500">Belum ada nilai. Mulai mengerjakan kuis untuk melihat nilai di sini.</p>
                </div>
            @else
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">No</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Kuis</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Skor</th>
                                <th class="px-6 py-3 text-xs font-semibold text-gray-500">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            @php $no = 1; @endphp
                            @foreach ($nilai as $n)
                                <tr>
                                    <td class="px-6 py-4 text-sm text-gray-600">{{ $no++ }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-700">{{ optional($n->kuis)->judul ?? '-' }}</td>
                                    <td class="px-6 py-4 text-sm font-medium {{ $n->skor >= 80 ? 'text-green-600' : 'text-gray-900' }}">{{ $n->skor }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-500">{{ $n->tanggal?->format('d M Y H:i') ?? '-' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="mt-4 flex justify-end">
                    {{ $nilai->links() }}
                </div>
            @endif
        </div>
    </div>
</x-layout>
