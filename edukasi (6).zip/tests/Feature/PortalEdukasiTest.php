<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Kelas;
use App\Models\Materi;
use App\Models\Kuis;
use App\Models\Soal;
use App\Models\Nilai;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PortalEdukasiTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    private function loginAs(User $user)
    {
        $this->actingAs($user);
        return $user;
    }

    /* ---------------- AUTENTIKASI ---------------- */

    public function test_login_berhasil()
    {
        $user = User::where('email', 'admin@portal.edu')->first();

        $response = $this->post('/login', [
            'email' => 'admin@portal.edu',
            'password' => 'admin123',
        ]);

        $response->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($user);
    }

    public function test_login_gagal_password_salah()
    {
        $response = $this->post('/login', [
            'email' => 'admin@portal.edu',
            'password' => 'salah123',
        ]);

        $response->assertRedirect('/login');
        $this->assertGuest();
    }

    public function test_logout()
    {
        $user = User::where('email', 'admin@portal.edu')->first();
        $this->actingAs($user);

        $response = $this->post('/logout');

        $response->assertRedirect('/login');
        $this->assertGuest();
    }

    /* ---------------- AUTORIZASI ROLE ---------------- */

    public function test_siswa_tidak_dapat_akses_admin()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $response = $this->get('/admin/dashboard');
        $response->assertStatus(403);
    }

    public function test_guru_tidak_dapat_akses_admin()
    {
        $guru = User::where('role', 'guru')->first();
        $this->loginAs($guru);

        $response = $this->get('/admin/users');
        $response->assertStatus(403);
    }

    public function test_admin_dapat_akses_dashboard_admin()
    {
        $admin = User::where('role', 'admin')->first();
        $this->loginAs($admin);

        $response = $this->get('/admin/dashboard');
        $response->assertStatus(200);
    }

    /* ---------------- MATERI ---------------- */

    public function test_guru_can_create_materi()
    {
        $guru = User::where('role', 'guru')->first();
        $this->loginAs($guru);

        $response = $this->post('/guru/materi', [
            'judul' => 'Materi Baru',
            'deskripsi' => 'Deskripsi materi baru',
        ]);

        $response->assertRedirect('/guru/materi');
        $this->assertDatabaseHas('materi', ['judul' => 'Materi Baru']);
    }

    public function test_siswa_tidak_dapat_buat_materi()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $response = $this->post('/guru/materi', [
            'judul' => 'X',
            'deskripsi' => 'Y',
        ]);

        $response->assertStatus(403);
    }

    public function test_user_tidak_dapat_edit_materi_orang_lain()
    {
        $guru = User::where('role', 'guru')->first();
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($guru);

        $materi = Materi::create([
            'judul' => 'Materi Guru',
            'deskripsi' => 'Deskripsi',
            'user_id' => $guru->id,
        ]);

        $this->actingAs($siswa);

        $response = $this->post('/guru/materi/' . $materi->id, [
            '_method' => 'PUT',
            'judul' => 'Diubah',
            'deskripsi' => 'Diubah',
        ]);

        $response->assertStatus(403);
    }

    /* ---------------- KUIS ---------------- */

    public function test_guru_can_create_kuis()
    {
        $guru = User::where('role', 'guru')->first();
        $this->loginAs($guru);

        $response = $this->post('/guru/kuis', [
            'judul' => 'Kuis Baru',
            'jumlah_soal' => 3,
            'tanggal' => now()->format('Y-m-d'),
        ]);

        $response->assertRedirect('/guru/kuis');
        $this->assertDatabaseHas('kuis', ['judul' => 'Kuis Baru']);
    }

    public function test_guru_can_create_soal()
    {
        $guru = User::where('role', 'guru')->first();
        $this->loginAs($guru);

        $kuis = Kuis::create([
            'judul' => 'Kuis Soal',
            'jumlah_soal' => 0,
            'tanggal' => now(),
            'user_id' => $guru->id,
        ]);

        $response = $this->post("/guru/kuis/{$kuis->id}/soal", [
            'pertanyaan' => '1+1 berapa?',
            'opsi_a' => '1',
            'opsi_b' => '2',
            'opsi_c' => '3',
            'opsi_d' => '4',
            'kunci_jawaban' => 'B',
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('soal', ['pertanyaan' => '1+1 berapa?', 'kunci_jawaban' => 'B']);
    }

    /* ---------------- QUIZ SCORING + DUPLIKAT ---------------- */

    public function test_siswa_scorer_dihitung_backend()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $guru = User::where('role', 'guru')->first();
        $kuis = Kuis::create([
            'judul' => 'Kuis Skor',
            'jumlah_soal' => 0,
            'tanggal' => now(),
            'user_id' => $guru->id,
        ]);

        Soal::create([
            'kuis_id' => $kuis->id,
            'pertanyaan' => 'S1?',
            'opsi_a' => 'A', 'opsi_b' => 'B', 'opsi_c' => 'C', 'opsi_d' => 'D',
            'kunci_jawaban' => 'A',
        ]);
        Soal::create([
            'kuis_id' => $kuis->id,
            'pertanyaan' => 'S2?',
            'opsi_a' => 'A', 'opsi_b' => 'B', 'opsi_c' => 'C', 'opsi_d' => 'D',
            'kunci_jawaban' => 'B',
        ]);
        $kuis->update(['jumlah_soal' => 2]);

        $soalKuisi = $kuis->soal()->get();

        $this->post("/siswa/kuis/{$kuis->id}/jawaban", [
            'soal_' . $soalKuisi->first()->id => 'A',
            'soal_' . $soalKuisi->last()->id => 'A', // salah
        ]);

        $this->post("/siswa/kuis/{$kuis->id}/kumpulkan");

        $this->assertDatabaseHas('nilai', [
            'user_id' => $siswa->id,
            'kuis_id' => $kuis->id,
            'skor' => 50,
        ]);
    }

    public function test_pengiriman_ulang_tidak_membuat_nilai_duplikat()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $guru = User::where('role', 'guru')->first();
        $kuis = Kuis::create([
            'judul' => 'Kuis Duplikat',
            'jumlah_soal' => 0,
            'tanggal' => now(),
            'user_id' => $guru->id,
        ]);

        Soal::create([
            'kuis_id' => $kuis->id,
            'pertanyaan' => 'S?',
            'opsi_a' => 'A', 'opsi_b' => 'B', 'opsi_c' => 'C', 'opsi_d' => 'D',
            'kunci_jawaban' => 'A',
        ]);
        $kuis->update(['jumlah_soal' => 1]);

        $this->post("/siswa/kuis/{$kuis->id}/jawaban", [
            'soal_' . $kuis->soal()->first()->id => 'A',
        ]);
        $this->post("/siswa/kuis/{$kuis->id}/kumpulkan");
        $this->post("/siswa/kuis/{$kuis->id}/kumpulkan"); // duplikat

        $this->assertDatabaseCount('nilai', 1);
    }

    public function test_tidak_bisa_manipulasi_skor_via_frontend()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $guru = User::where('role', 'guru')->first();
        $kuis = Kuis::create([
            'judul' => 'Kuis Manipulasi',
            'jumlah_soal' => 0,
            'tanggal' => now(),
            'user_id' => $guru->id,
        ]);

        Soal::create([
            'kuis_id' => $kuis->id,
            'pertanyaan' => 'S?',
            'opsi_a' => 'A', 'opsi_b' => 'B', 'opsi_c' => 'C', 'opsi_d' => 'D',
            'kunci_jawaban' => 'A',
        ]);
        $kuis->update(['jumlah_soal' => 1]);

        // coba kirim skor palsu langsung ke nilai (tidak ada route, tapi pastikan backend hitung)
        $this->post("/siswa/kuis/{$kuis->id}/jawaban", [
            'soal_' . $kuis->soal()->first()->id => 'B', // salah
        ]);
        $this->post("/siswa/kuis/{$kuis->id}/kumpulkan");

        $this->assertDatabaseHas('nilai', ['skor' => 0]);
        $this->assertDatabaseMissing('nilai', ['skor' => 100]);
    }

    /* ---------------- VIEWS / ROUTES ---------------- */

    public function test_dashboard_siswa_berstatus_200()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $response = $this->get('/dashboard');
        $response->assertStatus(200);
    }

    public function test_halaman_materi_siswa_berstatus_200()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $response = $this->get('/siswa/materi');
        $response->assertStatus(200);
    }

    public function test_halaman_kuis_siswa_berstatus_200()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $response = $this->get('/siswa/kuis');
        $response->assertStatus(200);
    }

    public function test_halaman_nilai_siswa_berstatus_200()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $response = $this->get('/siswa/nilai');
        $response->assertStatus(200);
    }

    public function test_halaman_profil_berstatus_200()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $response = $this->get('/profil');
        $response->assertStatus(200);
    }

    public function test_admin_daftar_pengguna_berstatus_200()
    {
        $admin = User::where('role', 'admin')->first();
        $this->loginAs($admin);

        $response = $this->get('/admin/users');
        $response->assertStatus(200);
    }

    public function test_admin_tambah_pengguna()
    {
        $admin = User::where('role', 'admin')->first();
        $this->loginAs($admin);

        $response = $this->post('/admin/users', [
            'name' => 'Budi',
            'email' => 'budi@portal.edu',
            'password' => 'password123',
            'role' => 'siswa',
        ]);

        $response->assertRedirect('/admin/users');
        $this->assertDatabaseHas('users', ['email' => 'budi@portal.edu']);
    }

    /* ---------------- RATA-RATA NILAI KOSONG ---------------- */

    public function test_rata_rata_nilai_tidak_error_kosong()
    {
        $siswa = User::where('role', 'siswa')->first();
        $this->loginAs($siswa);

        $response = $this->get('/siswa/nilai');
        $response->assertStatus(200);
    }

    /* ---------------- KELAS (ADMIN) ---------------- */

    public function test_admin_dapat_akses_halaman_kelas()
    {
        $admin = User::where('role', 'admin')->first();
        $this->loginAs($admin);

        $this->get('/admin/kelas')->assertStatus(200);
        $this->get('/admin/kelas/create')->assertStatus(200);
    }

    public function test_admin_dapat_edit_kelas()
    {
        $admin = User::where('role', 'admin')->first();
        $this->loginAs($admin);

        $kelas = Kelas::first();
        $response = $this->get("/admin/kelas/{$kelas->id}/edit");
        $response->assertStatus(200);
    }

    public function test_admin_dapat_update_kelas()
    {
        $admin = User::where('role', 'admin')->first();
        $this->loginAs($admin);

        $kelas = Kelas::first();
        $response = $this->put("/admin/kelas/{$kelas->id}", [
            'nama' => 'X IPA 1 Revisi',
            'deskripsi' => 'Deskripsi baru',
        ]);

        $response->assertRedirect('/admin/kelas');
        $this->assertDatabaseHas('kelas', ['nama' => 'X IPA 1 Revisi']);
    }

    public function test_guru_tidak_dapat_kelola_kelas()
    {
        $guru = User::where('role', 'guru')->first();
        $this->loginAs($guru);

        $this->post('/admin/kelas', ['nama' => 'X'])->assertStatus(403);
    }
}
