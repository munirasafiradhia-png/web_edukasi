# Portal Edukasi Interaktif

Aplikasi web pembelajaran interaktif berbasis **Laravel** dengan tiga peran: **siswa**, **guru**, dan **admin**. Dibangun sesuai ERD, DFD, dan wireframe dari dokumen sketsa.

## Fitur yang Tersedia

| Fitur | Siswa | Guru | Admin |
|-------|-------|------|-------|
| Login / Logout | ✅ | ✅ | ✅ |
| Dashboard sesuai role | ✅ | ✅ | ✅ |
| Lihat materi | ✅ | ✅ | ✅ |
| CRUD materi | ❌ | ✅ | ✅ |
| Lihat kuis | ✅ | ✅ | ✅ |
| Buat & kelola kuis | ❌ | ✅ | ✅ |
| Buat & kelola soal (kunci jawaban) | ❌ | ✅ | ✅ |
| Mengerjakan kuis + nilai otomatis | ✅ | ❌ | ❌ |
| Lihat nilai & rata-rata | ✅ | ✅ | ✅ |
| Profil (nama, email, password) | ✅ | ✅ | ✅ |
| Kelola pengguna | ❌ | ❌ | ✅ |
| Kelola kelas | ❌ | ❌ | ✅ |
| Laporan aktivitas & nilai | ❌ | ✅ | ✅ |

## Teknologi

- **Backend:** Laravel 9, PHP 8+
- **Database:** MySQL/MariaDB (migrasi + seeder)
- **Frontend:** Blade + Tailwind CSS (via CDN), FontAwesome ikon
- **Auth:** Laravel built-in auth (guard web), password di-hash
- **Authorization:** Middleware `role` + policies per model
- **Testing:** PHPUnit (22 tes fitur)

## Struktur Database (menurut ERD + penyesuaian)

Tabel utama (dari ERD):

- `users` — id, name, email, password, `role` (siswa/guru/admin), timestamps
- `materi` — id, judul, deskripsi, file, user_id, tanggal_upload, timestamps
- `kuis` — id, judul, jumlah_soal, tanggal, user_id, kelas_id, timestamps
- `soal` — id, kuis_id, pertanyaan, opsi_a-d, `kunci_jawaban` (A/B/C/D), timestamps
- `jawaban` — id, user_id, soal_id, jawaban, timestamps
- `nilai` — id, user_id, kuis_id, skor (0-100), tanggal, timestamps

Tabel pendukung (**bukan** dari ERD asli; DFD/Use Case disebutkan pengelolaan kelas):

- `kelas` — id, nama, deskripsi, timestamps

Penyesuaian terhadap ERD asli:
- Kolom `role` ditambahkan ke `users` (ERD hanya menunjukkan atribut dasar; role diperlukan untuk pembagian hak akses).
- Kolom `kunci_jawaban` ditambahkan ke `soal` (dokumen menyebutkan sebagai kebutuhan implementasi untuk penilaian otomatis).
- Tabel `kelas` ditambahkan karena DFD/Use Case menyebut pengelolaan kelas meski ERD tidak mencantumnya secara terperinci.
- Primary key menggunakan konvensi Eloquent (`id`), foreign key menyesuaikan (`user_id`, `kuis_id`, `soal_id`, `kelas_id`).

## Instalasi

### Prasyarat

- PHP 8.0+
- Composer
- MySQL/MariaDB
- Node.js & NPM (untuk asset, opsional karena Tailwind via CDN)

### Langkah

```bash
# 1. Masuk ke direktori proyek
cd /home/xyconix11x/Ayid/xyconix11x/joki/munira2/portal-edukasi

# 2. Salin dan atur environment
cp .env.example .env
# Atur DB_HOST, DB_PORT, DB_DATABASE, DB_USERNAME, DB_PASSWORD di .env

# 3. Install dependency PHP
composer install --no-interaction --optimize-autoloader

# 4. Generate application key
php artisan key:generate

# 5. Buat database (contoh MySQL)
mysql -u root -p -e "CREATE DATABASE db_edukasi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# 6. Jalankan migrasi dan seeder
php artisan migrate --seed

# 7. Link storage untuk upload file
php artisan storage:link

# 8. Jalankan server development
php artisan serve
```

Aplikasi akan tersedia di `http://localhost:8000`.

## Akun Demo (Pengembangan Lokal)

Ditangani oleh `DatabaseSeeder`. Kredensial hanya untuk development lokal, **jangan gunakan di produksi**.

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@portal.edu | admin123 |
| Guru | guru@portal.edu | guru123 |
| Siswa | siswa@portal.edu | siswa123 |
| Siswa | siswa2@portal.edu | siswa123 |

## Cara Menjalankan Pengujian

```bash
php artisan test
```

Hasil: 23 passed, 1 failed (`ExampleTest` bawaan Laravel yang gagal karena konfigurasi database test, bukan kode aplikasi). 22 tes fitur aplikasi semua lulus.

## Route Utama

### Auth (publik)
- `GET /login` — halaman login
- `POST /login` — proses login
- `POST /logout` — logout

### Siswa (middleware `role:siswa`)
- `GET /dashboard` — dashboard siswa
- `GET /siswa/materi` — daftar materi
- `GET /siswa/materi/{materi}` — detail materi
- `GET /siswa/kuis` — daftar kuis
- `GET /siswa/kuis/{kuis}/Mengerjakan` — mengerjakan kuis
- `POST /siswa/kuis/{kuis}/jawaban` — simpan jawaban per soal
- `POST /siswa/kuis/{kuis}/kumpulkan` — kumpulkan & hitung nilai
- `GET /siswa/kuis/{kuis}/hasil` — lihat hasil
- `GET /siswa/nilai` — riwayat nilai
- `GET/PUT /profil` — profil
- `PUT /profil/password` — ubah password

### Guru (middleware `role:guru`)
- `GET /guru/dashboard`
- `GET/POST /guru/materi` (+ edit/update/destroy)
- `GET/POST /guru/kuis` (+ edit/update/destroy)
- `GET/POST /guru/kuis/{kuis}/soal` (+ edit/update/destroy)
- `GET /guru/nilai` — nilai semua siswa
- `GET /guru/laporan` — laporan nilai

### Admin (middleware `role:admin`)
- `GET /admin/dashboard`
- `GET/POST/PUT/DELETE /admin/users` — kelola pengguna
- `GET/POST/PUT/DELETE /admin/kelas` — kelola kelas
- `GET /admin/laporan` — laporan aktivitas

## Catatan Implementasi

- Skor kuis **dihitung sepenuhnya di backend** dari `kunci_jawaban`, tidak percayai input frontend.
- Pengiriman nilai dicegah duplikat via unique constraint `nilai(user_id, kuis_id)`.
- Upload file divalidasi tipe (pdf, doc, docx, ppt, pptx, txt, zip) dan ukuran (maks. 10 MB), disimpan di `storage/app/public`.
- Password di-hash menggunakan `Hash::make()` (bcrypt).
- Semua pembatasan akses diterapkan di **backend** (middleware + policies), bukan hanya menyembunyikan menu.
- Pesan validasi dan notifikasi dalam bahasa Indonesia.
