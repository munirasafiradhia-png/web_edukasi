<aside class="hidden lg:flex lg:w-64 flex-col border-r border-gray-200 bg-white h-screen sticky top-0 z-40">
    <nav class="flex-1 py-6 space-y-1 px-4">
        <div class="mb-6">
            <h2 class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Menu</h2>
        </div>

        <?php
            $role = auth()->user()->role;
        ?>

        <?php if($role === 'siswa'): ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'fa-chart-pie'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'siswa.materi', 'label' => 'Materi', 'icon' => 'fa-book'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'siswa.kuis', 'label' => 'Kuis', 'icon' => 'fa-clipboard-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'siswa.nilai', 'label' => 'Nilai', 'icon' => 'fa-star'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'profil.edit', 'label' => 'Profil', 'icon' => 'fa-user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($role === 'guru'): ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'guru.dashboard', 'label' => 'Dashboard', 'icon' => 'fa-chart-pie'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'guru.materi.index', 'label' => 'Materi', 'icon' => 'fa-book'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'guru.kuis.index', 'label' => 'Kuis', 'icon' => 'fa-clipboard-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'guru.nilai', 'label' => 'Nilai Siswa', 'icon' => 'fa-star'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'profil.edit', 'label' => 'Profil', 'icon' => 'fa-user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($role === 'admin'): ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'admin.dashboard', 'label' => 'Dashboard', 'icon' => 'fa-chart-pie'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'admin.users.index', 'label' => 'Pengguna', 'icon' => 'fa-users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'admin.kelas.index', 'label' => 'Kelas', 'icon' => 'fa-school'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.sidebar-item', ['route' => 'admin.laporan', 'label' => 'Laporan', 'icon' => 'fa-file-alt'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <div class="mt-auto pt-6 border-t border-gray-200">
            <form action="<?php echo e(route('logout')); ?>" method="POST" class="w-full">
                <?php echo csrf_field(); ?>
                <button type="submit" class="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition border border-transparent focus:outline-none">
                    <i class="fas fa-sign-out-alt"></i>
                    Keluar
                </button>
            </form>
        </div>
    </nav>
</aside>

<!-- Mobile sidebar overlay -->
<div class="lg:hidden fixed inset-0 z-30" x-data="{ open: false }" @click.away="open = false">
    <div class="fixed inset-0 bg-black opacity-50 transition-opacity" @click="open = false" x-show="open" x-transition:enter="transition ease-in-out duration-200" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in-out duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"></div>

    <div class="fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-gray-200 transform transition-transform duration-200" :class="open ? 'translate-x-0' : '-translate-x-full'">
        <div class="flex justify-between items-center px-4 py-4 border-b border-gray-200">
            <span class="font-bold text-gray-900">Menu</span>
            <button @click="open = false" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <nav class="p-4 space-y-1">
            <?php if($role === 'siswa'): ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'fa-chart-pie'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'siswa.materi', 'label' => 'Materi', 'icon' => 'fa-book'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'siswa.kuis', 'label' => 'Kuis', 'icon' => 'fa-clipboard-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'siswa.nilai', 'label' => 'Nilai', 'icon' => 'fa-star'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'profil.edit', 'label' => 'Profil', 'icon' => 'fa-user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($role === 'guru'): ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'guru.dashboard', 'label' => 'Dashboard', 'icon' => 'fa-chart-pie'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'guru.materi.index', 'label' => 'Materi', 'icon' => 'fa-book'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'guru.kuis.index', 'label' => 'Kuis', 'icon' => 'fa-clipboard-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'guru.nilai', 'label' => 'Nilai Siswa', 'icon' => 'fa-star'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'profil.edit', 'label' => 'Profil', 'icon' => 'fa-user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($role === 'admin'): ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'admin.dashboard', 'label' => 'Dashboard', 'icon' => 'fa-chart-pie'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'admin.users.index', 'label' => 'Pengguna', 'icon' => 'fa-users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'admin.kelas.index', 'label' => 'Kelas', 'icon' => 'fa-school'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar-item-mobile', ['route' => 'admin.laporan', 'label' => 'Laporan', 'icon' => 'fa-file-alt'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </nav>
    </div>
</div>

<!-- Mobile hamburger -->
<div class="lg:hidden p-3">
    <button @click="open = !open" class="text-gray-600 hover:text-gray-900">
        <i class="fas fa-bars text-xl"></i>
    </button>
</div>
<?php /**PATH /home/xyconix11x/Ayid/xyconix11x/joki/munira2/portal-edukasi/resources/views/components/sidebar.blade.php ENDPATH**/ ?>