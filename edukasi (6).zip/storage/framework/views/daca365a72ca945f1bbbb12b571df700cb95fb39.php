<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['color' => 'blue', 'label' => '', 'value' => '', 'icon' => 'fa-info-circle']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['color' => 'blue', 'label' => '', 'value' => '', 'icon' => 'fa-info-circle']); ?>
<?php foreach (array_filter((['color' => 'blue', 'label' => '', 'value' => '', 'icon' => 'fa-info-circle']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="bg-white rounded-xl shadow border border-gray-200 p-6">
    <div class="flex items-center gap-4">
        <div class="p-3 rounded-lg <?php echo e($color === 'blue' ? 'bg-blue-100 text-blue-600' : ($color === 'green' ? 'bg-green-100 text-green-600' : ($color === 'purple' ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-600'))); ?>">
            <i class="fas <?php echo e($icon); ?>"></i>
        </div>
        <div>
            <p class="text-sm text-gray-500 font-medium"><?php echo e($label); ?></p>
            <p class="text-2xl font-bold text-gray-900"><?php echo e($value); ?></p>
        </div>
    </div>
</div>
<?php /**PATH /home/xyconix11x/Ayid/xyconix11x/joki/munira2/portal-edukasi/resources/views/components/card.blade.php ENDPATH**/ ?>