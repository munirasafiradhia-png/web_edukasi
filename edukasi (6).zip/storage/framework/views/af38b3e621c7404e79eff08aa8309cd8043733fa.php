<?php
    $isActive = request()->routeIs($route);
?>

<a href="<?php echo e(route($route)); ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition <?php echo e($isActive ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-100'); ?>">
    <i class="fas <?php echo e($icon); ?>"></i>
    <span><?php echo e($label); ?></span>
</a>
<?php /**PATH /home/xyconix11x/Ayid/xyconix11x/joki/munira2/portal-edukasi/resources/views/components/sidebar-item.blade.php ENDPATH**/ ?>