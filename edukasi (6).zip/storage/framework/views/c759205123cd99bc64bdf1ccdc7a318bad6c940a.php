<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Kelola Kuis']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Kelola Kuis']); ?>
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Kelola Kuis</h1>
                <p class="text-gray-600">Buat dan kelola kuis untuk siswa.</p>
            </div>
            <a href="<?php echo e(route('guru.kuis.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg font-medium transition shadow-md">
                <i class="fas fa-plus mr-2"></i> Buat Kuis
            </a>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['message' => session('success'),'type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('success')),'type' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="bg-white rounded-xl shadow border border-gray-200 overflow-hidden">
        <?php if($kuis->isEmpty()): ?>
            <div class="p-12 text-center">
                <div class="text-gray-400 mb-4"><i class="fas fa-clipboard-list text-4xl"></i></div>
                <p class="text-gray-500">Belum ada kuis. Buat kuis pertama Anda.</p>
                <a href="<?php echo e(route('guru.kuis.create')); ?>" class="mt-4 inline-block text-blue-600 font-medium hover:underline">Buat Kuis</a>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">No</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Judul</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Jumlah Soal</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500">Tanggal</th>
                            <th class="px-6 py-3 text-xs font-semibold text-gray-500 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $kuis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($no++); ?></td>
                                <td class="px-6 py-4 text-sm font-medium text-gray-900"><?php echo e($k->judul); ?></td>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($k->jumlah_soal); ?> soal</td>
                                <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($k->tanggal?->format('d M Y') ?? '-'); ?></td>
                                <td class="px-6 py-4 text-sm text-right">
                                    <a href="<?php echo e(route('guru.kuis.soal.index', $k)); ?>" class="text-blue-600 hover:underline mr-3">Kelola Soal</a>
                                    <a href="<?php echo e(route('guru.kuis.edit', $k)); ?>" class="text-blue-600 hover:underline mr-3">Edit</a>
                                    <form action="<?php echo e(route('guru.kuis.destroy', $k)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:underline" onclick="return confirm('Yakin ingin menghapus kuis ini? Semua soal dan nilai terkait akan ikut terhapus.')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($kuis->links()); ?>

        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/xyconix11x/Ayid/xyconix11x/joki/munira2/portal-edukasi/resources/views/guru/kuis/index.blade.php ENDPATH**/ ?>