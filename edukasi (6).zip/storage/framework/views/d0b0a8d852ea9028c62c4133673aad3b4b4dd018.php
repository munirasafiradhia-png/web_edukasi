<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['label' => '', 'value' => '', 'color' => 'blue']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['label' => '', 'value' => '', 'color' => 'blue']); ?>
<?php foreach (array_filter((['label' => '', 'value' => '', 'color' => 'blue']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
    <?php echo e($color === 'blue' ? 'bg-blue-100 text-blue-700' : ($color === 'green' ? 'bg-green-100 text-green-700' : ($color === 'red' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'))); ?>">
    <?php echo e($value); ?>

</span>
<?php /**PATH /home/xyconix11x/Ayid/xyconix11x/joki/munira2/portal-edukasi/resources/views/components/badge.blade.php ENDPATH**/ ?>