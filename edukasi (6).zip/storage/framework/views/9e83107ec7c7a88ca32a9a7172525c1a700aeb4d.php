<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Portal Edukasi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-blue-50 min-h-screen flex items-center justify-center px-4">

    <div class="max-w-4xl w-full bg-white rounded-2xl shadow-xl overflow-hidden flex flex-col lg:flex-row">
        <!-- Kiri: identitas/logo -->
        <div class="hidden lg:flex lg:w-1/2 bg-blue-600 p-12 flex-col justify-between text-white">
            <div>
                <div class="flex items-center gap-3 mb-6">
                    <div class="bg-white/20 rounded-lg p-3">
                        <i class="fas fa-graduation-cap text-2xl"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold">Portal Edukasi</h1>
                        <p class="text-blue-100 text-sm">Media Pembelajaran Interaktif</p>
                    </div>
                </div>
                <p class="text-blue-100/90 leading-relaxed max-w-xs">
                    Selamat datang di Portal Edukasi Interaktif — platform pembelajaran digital untuk mengakses materi, mengerjakan kuis, dan melihat nilai pembelajaran.
                </p>
            </div>
            <div class="mt-auto">
                <p class="text-blue-200 text-xs font-medium tracking-wider uppercase">Siswa · Guru · Admin</p>
            </div>
        </div>

        <!-- Kanan: form login -->
        <div class="w-full lg:w-1/2 p-8 lg:p-12 flex flex-col justify-center">
            <div class="mx-auto max-w-md">
                <h2 class="text-2xl font-bold text-gray-900 mb-2">Masuk</h2>
                <p class="text-gray-600 mb-8">Silakan login dengan akun Anda.</p>

                <?php if(session('error')): ?>
                    <div class="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 text-red-800 text-sm">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 text-red-800 text-sm">
                        <ul class="list-disc list-inside space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('login.post')); ?>" method="POST" class="space-y-4">
                    <?php echo csrf_field(); ?>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                            placeholder="nama@email.com">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                        <input type="password" name="password" required
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                            placeholder="••••••••">
                    </div>

                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <input type="checkbox" name="remember" id="remember" class="rounded text-blue-600 focus:ring-blue-500">
                            <label for="remember" class="text-sm text-gray-600">Ingat saya</label>
                        </div>
                    </div>

                    <button type="submit"
                        class="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5 rounded-lg transition shadow-md">
                        Login
                    </button>
                </form>

                <p class="mt-6 text-center text-sm text-gray-600">
                    Belum punya akun?
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\User::class)): ?>
                        <a href="<?php echo e(route('admin.users.create')); ?>" class="text-blue-600 font-medium hover:underline">Daftar melalui admin</a>
                    <?php else: ?>
                        <a href="#" class="text-blue-600 font-medium hover:underline">Hubungi admin untuk pendaftaran</a>
                    <?php endif; ?>
                </p>

                <div class="mt-6 pt-6 border-t border-gray-200">
                    <p class="text-xs text-gray-400 text-center uppercase tracking-wider">Akun pengembangan (demo)</p>
                    <ul class="text-xs text-gray-500 text-center space-y-1 mt-2">
                        <li>Admin: admin@portal.edu / admin123</li>
                        <li>Guru: guru@portal.edu / guru123</li>
                        <li>Siswa: siswa@portal.edu / siswa123</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
<?php /**PATH /home/xyconix11x/Ayid/xyconix11x/joki/munira2/portal-edukasi/resources/views/auth/login.blade.php ENDPATH**/ ?>