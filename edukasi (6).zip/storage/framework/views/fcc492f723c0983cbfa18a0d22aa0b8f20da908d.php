<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['type' => 'submit', 'label' => 'Simpan', 'color' => 'blue', 'class' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type' => 'submit', 'label' => 'Simpan', 'color' => 'blue', 'class' => '']); ?>
<?php foreach (array_filter((['type' => 'submit', 'label' => 'Simpan', 'color' => 'blue', 'class' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<button
    type="<?php echo e($type); ?>"
    class="w-full px-4 py-2.5 rounded-lg font-medium text-white transition
    <?php echo e($color === 'blue' ? 'bg-blue-600 hover:bg-blue-700' : ($color === 'green' ? 'bg-green-600 hover:bg-green-700' : ($color === 'red' ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-600 hover:bg-gray-700'))); ?>

    <?php echo e($class); ?>"
><?php echo e($label); ?></button>
<?php /**PATH /home/xyconix11x/Ayid/xyconix11x/joki/munira2/portal-edukasi/resources/views/components/button.blade.php ENDPATH**/ ?>