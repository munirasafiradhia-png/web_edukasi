<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\MateriController;
use App\Http\Controllers\KuisController;
use App\Http\Controllers\SoalController;
use App\Http\Controllers\JawabanController;
use App\Http\Controllers\NilaiController;
use App\Http\Controllers\ProfilController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\KelasController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/login', [AuthController::class, 'showLogin'])->name('login')->middleware('guest');
Route::post('/login', [AuthController::class, 'login'])->name('login.post')->middleware('guest');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/', function () {
    return redirect()->route('login');
});

// Shared dashboard
Route::get('/dashboard', [DashboardController::class, 'show'])->name('dashboard')->middleware('auth');

// ---------- SHARED (auth, all roles) ----------
Route::middleware(['auth'])->group(function () {
    Route::get('/profil', [ProfilController::class, 'edit'])->name('profil.edit');
    Route::put('/profil', [ProfilController::class, 'update'])->name('profil.update');
    Route::put('/profil/password', [ProfilController::class, 'updatePassword'])->name('profil.password');
});

// ---------- SISWA ----------
Route::middleware(['auth', 'role:siswa'])->group(function () {
    Route::get('/siswa/materi', [MateriController::class, 'siswaIndex'])->name('siswa.materi');
    Route::get('/siswa/materi/{materi}', [MateriController::class, 'siswaShow'])->name('siswa.materi.show');

    Route::get('/siswa/kuis', [KuisController::class, 'siswaIndex'])->name('siswa.kuis');
    Route::get('/siswa/kuis/{kuis}/Mengerjakan', [JawabanController::class, 'create'])->name('siswa.kuis.mengerjakan');
    Route::post('/siswa/kuis/{kuis}/jawaban', [JawabanController::class, 'store'])->name('siswa.kuis.jawaban');
    Route::post('/siswa/kuis/{kuis}/kumpulkan', [JawabanController::class, 'kumpulkan'])->name('siswa.kuis.kumpulkan');
    Route::get('/siswa/kuis/{kuis}/hasil', [JawabanController::class, 'hasil'])->name('siswa.kuis.hasil');

    Route::get('/siswa/nilai', [NilaiController::class, 'siswaIndex'])->name('siswa.nilai');
});

// ---------- GURU ----------
Route::middleware(['auth', 'role:guru'])->group(function () {
    Route::get('/guru/dashboard', [DashboardController::class, 'guru'])->name('guru.dashboard');

    Route::resource('/guru/materi', MateriController::class)->except(['show'])->names('guru.materi');

    Route::resource('/guru/kuis', KuisController::class)->except(['show'])->names('guru.kuis');
    Route::resource('/guru/kuis/{kuis}/soal', SoalController::class)->except(['show', 'index'])->names('guru.kuis.soal');
    Route::get('/guru/kuis/{kuis}/soal', [SoalController::class, 'index'])->name('guru.kuis.soal.index');

    Route::get('/guru/nilai', [NilaiController::class, 'guruIndex'])->name('guru.nilai');
    Route::get('/guru/laporan', [NilaiController::class, 'laporan'])->name('guru.laporan');
});

// ---------- ADMIN ----------
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/dashboard', [DashboardController::class, 'admin'])->name('admin.dashboard');

    Route::resource('/admin/users', AdminController::class)->except(['create'])->names('admin.users');
    Route::get('/admin/users/create', [AdminController::class, 'create'])->name('admin.users.create');

    Route::resource('/admin/kelas', KelasController::class)->except(['show'])->parameters(['kelas' => 'kelas'])->names('admin.kelas');

    Route::get('/admin/laporan', [AdminController::class, 'laporan'])->name('admin.laporan');
});
